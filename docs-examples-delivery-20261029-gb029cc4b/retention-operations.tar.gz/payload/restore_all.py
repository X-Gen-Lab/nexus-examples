import sys,os,json,hashlib,shutil,tarfile
from pathlib import Path,PurePosixPath
sys.path.insert(0,"/workspace/nexus")
from tools.dev.process import run
os.nice(15);c=Path(__file__).resolve().parent;nsname="docs-examples-delivery-20261029-gb029cc4b";data=c/"remote"/nsname;leaf=json.loads((data/"final-index.json").read_text());tools=c/"remote-verifiers";tools.mkdir();expected={x["path"]:x for x in leaf["verifiers"]["files"]};seen=set()
with tarfile.open(data/"verification-tools.tar.gz","r:gz") as archive:
 for member in archive:
  rel=PurePosixPath(member.name)
  if rel.is_absolute() or ".." in rel.parts or not member.isfile() or member.name not in expected or member.name in seen:raise RuntimeError("verifier closure differs")
  body=archive.extractfile(member).read();identity=expected[member.name]
  if len(body)!=identity["bytes"] or hashlib.sha256(body).hexdigest()!=identity["sha256"]:raise RuntimeError("verifier source identity differs")
  path=tools/str(rel);path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body);path.chmod(member.mode&0o777);seen.add(member.name)
if seen!=set(expected):raise RuntimeError("verifier closure incomplete")
results=[]
def command(name,argv):
 result=run(argv,cwd=c,env=os.environ.copy(),log=c/(name+".log"),timeout=900,stage="private_assets_"+name)
 if result.returncode:raise SystemExit(name+" failed")
 return str(c/(name+".command.json"))
for package in leaf["packages"]:
 name=package["name"];envelope=data/package["original_package"];archive=data/package["original_archive"];dest=c/("restored-"+name);needed=package["expanded_bytes"]+64*1024**2
 if dest.exists():raise RuntimeError("fresh independent restore output already exists")
 if shutil.disk_usage(c).free-needed<250*1024**2:raise RuntimeError("independent overlay restore capacity guard")
 before=shutil.disk_usage(c).free
 verify=command(name+"-remote-store-verify",[sys.executable,"-B",str(tools/"tools/evidence/store.py"),"verify","--package",str(envelope),"--archive",str(archive),"--report",str(c/(name+"-remote-store-verify.json"))])
 restored=command(name+"-independent-store-restore",[sys.executable,"-B",str(tools/"tools/evidence/store.py"),"restore","--package",str(envelope),"--archive",str(archive),"--destination",str(dest),"--report",str(c/(name+"-independent-store-restore.json"))])
 sdk=None
 if name=="execution-and-sdk":
  source=dest/"local-ci/source-sdk/share/nexus/src"
  sdk=command(name+"-restored-sdk-verify",[sys.executable,"-B",str(source/"cmake/package/package_source_sdk.py"),"--verify",str(source)])
 results.append({"name":name,"original_archive_sha256":package["archive_sha256"],"original_manifest_sha256":package["manifest_sha256"],"original_envelope_unchanged":True,"actual_store_verify_receipt":verify,"actual_independent_restore_receipt":restored,"actual_restored_SDK_verify_receipt":sdk,"full_member_SHA_size_mode_and_inventory":"verified_by_original_store_verify_and_restore","fresh_duplicate_cleanup_only_after_maintained_verification":True,"free_overlay_before":before})
 shutil.rmtree(dest);results[-1]["free_overlay_after_cleanup"]=shutil.disk_usage(c).free
 (c/"restores.json").write_text(json.dumps({"status":("four_original_packages_remote_verified_and_independently_restored" if len(results)==len(leaf["packages"]) else "independent_restores_in_progress"),"payload_commit":json.loads((c/"payload-push.json").read_text())["commit"],"restores":results,"no_build_or_test_rerun":True,"physical_hil":"not_executed","recipe_reproducible":False,"original_source_and_archives_untouched":True},indent=2)+"\n")
command("closing-private-visibility",["gh","api","repos/X-Gen-Lab/nexus-examples","--jq","{visibility,private,default_branch}"])
print(json.dumps({"packages":len(results),"actual_store_verify_restore_SDK_commands":9,"all_actual_exit_codes":0,"RAMfree":shutil.disk_usage("/dev/shm").free,"overlayfree":shutil.disk_usage("/workspace").free}))
