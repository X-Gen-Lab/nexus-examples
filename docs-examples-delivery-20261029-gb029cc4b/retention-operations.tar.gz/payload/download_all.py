import sys,os,json,hashlib,shutil
from pathlib import Path
sys.path.insert(0,"/workspace/nexus")
from tools.dev.process import run
os.nice(15);c=Path(__file__).resolve().parent;w=c/"asset-worktree";remote=c/"remote";remote.mkdir();push=json.loads((c/"payload-push.json").read_text());commit=push["commit"];registry=json.loads((w/"assets.json").read_text());members=list(registry["members"])
for rel in ["README.md","assets.json","verify_assets.py"]:
 p=w/rel;d=p.read_bytes();members.append({"path":rel,"bytes":len(d),"sha256":hashlib.sha256(d).hexdigest()})
observed=[]
for number,member in enumerate(members):
 name="http-"+str(number+1).zfill(2);receipt=c/(name+"-actual-gh.json")
 argv=[sys.executable,"-B",str(c/"download_member.py"),"X-Gen-Lab/nexus-examples",commit,member["path"],str(remote/member["path"]),str(member["bytes"]),member["sha256"],str(receipt)]
 result=run(argv,cwd=c,env=os.environ.copy(),log=c/(name+".log"),timeout=300,stage="private_assets_"+name)
 if result.returncode:raise SystemExit(name+" failed")
 observed.append(json.loads(receipt.read_text()));(c/"downloads.json").write_text(json.dumps({"commit":commit,"members":observed,"expected":len(members)},indent=2)+"\n")
result=run([sys.executable,"-B","verify_assets.py"],cwd=remote,env=os.environ.copy(),log=c/"remote-full-inventory-verify.log",timeout=300,stage="private_assets_remote_full_inventory")
if result.returncode:raise SystemExit("remote full inventory failed")
print(json.dumps({"commit":commit,"downloaded_members":len(observed),"registered_members":len(registry["members"]),"bytes":sum(x["bytes"] for x in observed),"remote_inventory_exit":result.returncode,"RAMfree":shutil.disk_usage("/dev/shm").free,"overlayfree":shutil.disk_usage("/workspace").free}))
