"""One authenticated exact-commit binary download; no credentials are printed."""
import sys,json,subprocess,time,hashlib,shutil,os
from pathlib import Path
repo,commit,relative,destination,expected_size,expected_sha,receipt=sys.argv[1:]
destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
if shutil.disk_usage(destination.parent).free-int(expected_size)<250*1024**2:raise RuntimeError("overlay download reserve")
command=["gh","api","repos/"+repo+"/contents/"+relative+"?ref="+commit,"-H","Accept: application/vnd.github.raw+json"]
started=time.time_ns()
with destination.open("xb") as stdout:
 result=subprocess.run(command,stdout=stdout,stderr=subprocess.PIPE,timeout=240)
finished=time.time_ns();Path(receipt+".stderr").write_bytes(result.stderr)
with destination.open("rb") as stream:actual_sha=hashlib.file_digest(stream,"sha256").hexdigest()
actual_size=destination.stat().st_size
record={"command":command,"storage_commit":commit,"repository":repo,"repository_visibility":"private","member":relative,"destination":str(destination),"actual_exit_code":result.returncode,"started_ns":started,"finished_ns":finished,"bytes":actual_size,"sha256":actual_sha,"size_matches":actual_size==int(expected_size),"SHA_matches":actual_sha==expected_sha,"authentication":"existing gh credential; never read or printed","transport":"authenticated contents API raw binary stdout file; no public raw domain"}
Path(receipt).write_text(json.dumps(record,indent=2)+"\n")
if result.returncode or not record["size_matches"] or not record["SHA_matches"]:raise SystemExit("Authenticated exact member download failed: "+relative)
print(json.dumps({"member":relative,"bytes":actual_size,"sha256":actual_sha,"actual_exit_code":result.returncode}))
