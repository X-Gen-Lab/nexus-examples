import sys,os,json,hashlib,shutil,subprocess
from pathlib import Path
sys.path.insert(0,"/workspace/nexus")
from tools.dev.process import run
os.nice(15);c=Path(__file__).resolve().parent;w=c/"asset-worktree";ns=w/"docs-examples-delivery-20261029-gb029cc4b";raw=c/"proof-raw";raw.mkdir();selection=[]
for p in list(c.iterdir()):
 if p.is_file():shutil.copy2(p,raw/p.name);selection.append(p.name)
 elif p.is_dir() and p.name.endswith(".attempts"):
  shutil.copytree(p,raw/p.name);selection.append(p.name+"/")
(raw/"selection.json").write_text(json.dumps({"actual_control_members":selection,"excluded":"asset-worktree and remote large original archives already retained exactly in payload; restored duplicate trees removed only after maintained full verification; no source/SDK original deletion","no_credentials_read_or_printed":True},indent=2)+"\n")
def command(name,args,timeout=300):
 result=run(args,cwd=w,env=os.environ.copy(),log=c/(name+".log"),timeout=timeout,stage="private_assets_"+name)
 if result.returncode:raise SystemExit(name+" failed")
 return result
store=c/"remote-verifiers/tools/evidence/store.py"
command("proof-export",[sys.executable,"-B",str(store),"export","--source",str(raw),"--store",str(c/"proof-store"),"--report",str(c/"proof-package.json")])
package=json.loads((c/"proof-package.json").read_text());archive=Path(package["archive"]["path"])
command("proof-local-verify",[sys.executable,"-B",str(store),"verify","--package",str(c/"proof-package.json"),"--report",str(c/"proof-local-verify.json")])
command("proof-local-restore",[sys.executable,"-B",str(store),"restore","--package",str(c/"proof-package.json"),"--destination",str(c/"proof-local-restore"),"--report",str(c/"proof-local-restore.json")])
shutil.rmtree(c/"proof-local-restore")
shutil.copyfile(archive,ns/"retention-operations.tar.gz");shutil.copyfile(c/"proof-package.json",ns/"retention-operations-package.json")
push=json.loads((c/"payload-push.json").read_text());downloads=json.loads((c/"downloads.json").read_text());restores=json.loads((c/"restores.json").read_text())
index={"kind":"private_examples_exact_remote_retention_and_independent_recovery","repository":"X-Gen-Lab/nexus-examples","repository_visibility":"private","platform_commit":"7590b2d457d6042112abb78a4f4df74d613df6ff","examples_commit":"b029cc4b7e8e7a7d3e5e1f1be080a0aa24b1ee09","payload_storage_commit":push["commit"],"payload_index_url":push["private_final_index_url"],"original_payload_index_and_original_archive_envelope_metadata_unchanged":True,"authenticated_exact_commit_retrieval":{"registered_members":15,"root_files":3,"all18_size_and_SHA_matched":True,"existing_asset_validator_actual_exit":0,"raw_media":"application/vnd.github.raw","retained_initial_failure":"application/vnd.github.raw+json yielded actualexit1/2B/transform short source buffer; original failure and successful same-endpoint standardraw retry are retained in operations proof; failed attempt is not marked successful","download_observations":"retention-operations.tar.gz:downloads.json"},"original_packages":restores["restores"],"actual_maintained_verifier_commands":{"store_verify":4,"independent_store_restore":4,"restored_SDK_integrity":1,"all_actual_exit_codes":0},"no_build_or_application_test_rerun":True,"proof_package":{"original_envelope":"retention-operations-package.json","archive":"retention-operations.tar.gz","archive_sha256":package["archive"]["sha256"],"archive_bytes":package["archive"]["size"],"manifest_sha256":package["manifest_sha256"],"files":package["files"],"expanded_bytes":package["bytes"]},"physical_hil":"not_executed","recipe_reproducible":False,"fresh_daemon_restore":"not_executed","Pages":"not_performed","formal_Release":"not_performed","public_private_boundary":"Original examples evidence and detailed full status remain private; the public platform index may link only to this authenticated entry.","future_public_commit_dependency":False,"proof_storage_note":"This appended record describes completed payload recovery. Its own append commit is transported and verified separately; no self-referential or recursive proof success is invented."}
(ns/"recovery-index.json").write_text(json.dumps(index,ensure_ascii=False,indent=2)+"\n")
(ns/"RETENTION.md").write_text("# Independently recovered private delivery\n\nRead `recovery-index.json` for the actual completed authenticated exact-commit payload recovery and all four original package restores, plus restored SDK integrity verification. The original payload index retains its historical preparation snapshot. `retention-operations.tar.gz` is the original portable store package containing raw CLI receipts, original failed raw-media attempt, successful authenticated retry and exact verification reports. No build/test or product release is inferred from retention.\n")
registry=json.loads((w/"assets.json").read_text());new=[]
for name in ["retention-operations.tar.gz","retention-operations-package.json","recovery-index.json","RETENTION.md"]:
 p=ns/name;body=p.read_bytes();new.append({"path":p.relative_to(w).as_posix(),"bytes":len(body),"sha256":hashlib.sha256(body).hexdigest()})
registry["members"].extend(new);(w/"assets.json").write_text(json.dumps(registry,indent=2)+"\n")
command("proof-stage-verify",[sys.executable,"-B","verify_assets.py"])
command("proof-stage-add",["git","add","--","assets.json",*(x["path"] for x in new)])
command("proof-commit",["git","commit","-m","docs(delivery): retain private artifact recovery proof"])
commit=subprocess.run(["git","rev-parse","HEAD"],cwd=w,check=True,text=True,stdout=subprocess.PIPE).stdout.strip()
base=["git","-c","gc.auto=0","-c","pack.threads=1","-c","pack.window=0","-c","credential.helper=","-c","credential.helper=!gh auth git-credential"]
command("proof-fresh-remote",base+["ls-remote","--heads","origin","refs/heads/delivery-assets"])
if (c/"proof-fresh-remote.log").read_text().split()[0]!=push["commit"]:raise SystemExit("fresh remote lease differs; no push")
command("proof-push",base+["push","origin","HEAD:refs/heads/delivery-assets"],600)
command("proof-readback",base+["ls-remote","--heads","origin","refs/heads/delivery-assets"])
if (c/"proof-readback.log").read_text().split()[0]!=commit:raise SystemExit("proof remote differs")
record={"commit":commit,"parent_payload_commit":push["commit"],"new_members":new,"all_registered_members":len(registry["members"]),"private_final_index_url":"https://github.com/X-Gen-Lab/nexus-examples/blob/"+commit+"/"+ns.name+"/recovery-index.json","normal_hook":True,"nonforce_push":True,"exact_new_member_download_and_proof_restore":"pending"};(c/"proof-push.json").write_text(json.dumps(record,indent=2)+"\n");print(json.dumps(record))
