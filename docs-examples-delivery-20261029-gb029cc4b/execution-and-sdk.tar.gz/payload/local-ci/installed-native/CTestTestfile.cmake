# CMake generated Testfile for 
# Source directory: /dev/shm/nexus-examples-final/reproduction
# Build directory: /dev/shm/nexus-examples-final/build/p6-7590b2d4/local-ci/installed-native
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[installed_platform_reference]=] "/dev/shm/nexus-examples-final/build/p6-7590b2d4/local-ci/installed-native/bin/nexus_firmware")
set_tests_properties([=[installed_platform_reference]=] PROPERTIES  TIMEOUT "10" _BACKTRACE_TRIPLES "/dev/shm/nexus-examples-final/reproduction/CMakeLists.txt;13;add_test;/dev/shm/nexus-examples-final/reproduction/CMakeLists.txt;0;")
subdirs("nexus-sdk")
