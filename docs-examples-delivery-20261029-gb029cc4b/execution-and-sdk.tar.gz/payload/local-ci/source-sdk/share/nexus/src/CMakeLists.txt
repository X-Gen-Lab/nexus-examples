cmake_minimum_required(VERSION 3.31)
include("${CMAKE_CURRENT_LIST_DIR}/cmake/platform/TargetPolicy.cmake")
nexus_require_build_generator()
if(TARGET Nexus::Config)
    message(FATAL_ERROR "One build may contain only one resolved Nexus assembly")
endif()
set(NEXUS_SOURCE_DIR "${CMAKE_CURRENT_LIST_DIR}")
find_package(Python3 3.11 REQUIRED COMPONENTS Interpreter)
# Validate source SDK bytes before loading its resolver or metadata modules.
include("${NEXUS_SOURCE_DIR}/cmake/platform/SDK.cmake")
execute_process(
    COMMAND "${Python3_EXECUTABLE}" -B
        "${CMAKE_CURRENT_LIST_DIR}/tools/configure/metadata.py" --version
    RESULT_VARIABLE _nexus_version_result
    OUTPUT_VARIABLE NEXUS_PLATFORM_VERSION
    ERROR_VARIABLE _nexus_version_error
    OUTPUT_STRIP_TRAILING_WHITESPACE)
if(NOT _nexus_version_result EQUAL 0)
    message(FATAL_ERROR "Nexus version policy rejected: ${_nexus_version_error}")
endif()
project(nexus VERSION "${NEXUS_PLATFORM_VERSION}" LANGUAGES C ASM)

# A consumer selects one assembly; there is no Kconfig/cache fallback truth.
set(NEXUS_BINARY_DIR "${CMAKE_CURRENT_BINARY_DIR}")
if(NEXUS_SOURCE_DIR STREQUAL NEXUS_BINARY_DIR)
    message(FATAL_ERROR "Nexus requires an out-of-source build")
endif()
set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_C_EXTENSIONS OFF)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)
set(CMAKE_ARCHIVE_OUTPUT_DIRECTORY "${NEXUS_BINARY_DIR}/lib")
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${NEXUS_BINARY_DIR}/bin")
set(NEXUS_ASSEMBLY_FILE "" CACHE FILEPATH "One external authored TOML assembly")
if(NOT NEXUS_ASSEMBLY_FILE)
    if(NOT PROJECT_IS_TOP_LEVEL)
        message(FATAL_ERROR "External consumers must set NEXUS_ASSEMBLY_FILE")
    endif()
    set(NEXUS_ASSEMBLY_FILE
        "${NEXUS_SOURCE_DIR}/tools/configure/assemblies/native.toml")
endif()
foreach(legacy NEXUS_CONFIG_FILE NEXUS_PLATFORM NEXUS_OSAL_BACKEND
               NEXUS_BOARD_DIR NEXUS_FLASH_LAYOUT_FILE)
    if(DEFINED ${legacy} AND NOT "${${legacy}}" STREQUAL "")
        message(FATAL_ERROR "${legacy} is removed; use NEXUS_ASSEMBLY_FILE")
    endif()
endforeach()
include("${NEXUS_SOURCE_DIR}/cmake/platform/Configure.cmake")
nexus_resolve_assembly()
include("${NEXUS_SOURCE_DIR}/cmake/platform/Options.cmake")
include("${NEXUS_SOURCE_DIR}/cmake/platform/CMSISCore.cmake")
nexus_cmsis_core_include(NEXUS_CMSIS_CORE_INCLUDE_DIR)
include("${NEXUS_SOURCE_DIR}/cmake/platform/Firmware.cmake")

add_subdirectory(core)
add_subdirectory(arch)
add_subdirectory(io)
add_subdirectory(os)
add_subdirectory(components EXCLUDE_FROM_ALL)
include("${NEXUS_SOURCE_DIR}/cmake/platform/Components.cmake")
nexus_resolve_components(nexus_component_targets ${NEXUS_SELECTED_COMPONENTS})
if(NEXUS_SOC_FAMILY STREQUAL "native")
    add_subdirectory("${NEXUS_SOC_SOURCE_DIRECTORY}")
    set(nexus_provider nexus_io_native)
else()
    add_subdirectory("${NEXUS_SOC_SOURCE_DIRECTORY}")
    set(nexus_provider "nexus_soc_${NEXUS_SOC_FAMILY}")
endif()
add_library(nexus_platform STATIC "${NEXUS_CONFIG_DIR}/bindings.c")
target_include_directories(nexus_platform PUBLIC "${NEXUS_CONFIG_DIR}"
    PRIVATE "${NEXUS_SOURCE_DIR}/io/private")
target_link_libraries(nexus_platform PUBLIC ${nexus_provider}
    PRIVATE nexus_build_options nexus_owned_warnings Nexus::Arch)
if(NEXUS_RUNTIME_POWER)
    target_link_libraries(nexus_platform PUBLIC Nexus::ClockDomain)
    target_include_directories(nexus_platform PRIVATE
        "${NEXUS_SOURCE_DIR}/components/clock_domain/private")
    list(APPEND nexus_component_targets Nexus::ClockDomain)
endif()
if(NEXUS_IO_CYCLE_PROBES)
    target_link_libraries(nexus_platform PRIVATE Nexus::IOCycleProbe)
    target_compile_definitions(nexus_platform PUBLIC NX_IO_CYCLE_PROBES=1)
endif()
if(NEXUS_SYSTEM_PRIVATE_INCLUDES)
    target_include_directories(nexus_platform PRIVATE
        ${NEXUS_SYSTEM_PRIVATE_INCLUDES})
endif()
if(NEXUS_SYSTEM_VENDOR_INCLUDES)
    target_include_directories(nexus_platform SYSTEM PRIVATE
        ${NEXUS_SYSTEM_VENDOR_INCLUDES})
endif()
if(NOT NEXUS_SOC_FAMILY STREQUAL "native")
    nexus_use_cmsis_core(nexus_platform)
endif()
if(NEXUS_SYSTEM_COMPILE_DEFINITIONS)
    target_compile_definitions(nexus_platform PRIVATE
        ${NEXUS_SYSTEM_COMPILE_DEFINITIONS})
endif()
set_target_properties(nexus_platform PROPERTIES
    NEXUS_SOURCE_DIR "${NEXUS_SOURCE_DIR}"
    NEXUS_CONFIG_DIR "${NEXUS_CONFIG_DIR}"
    NEXUS_SOC_FAMILY "${NEXUS_SOC_FAMILY}"
    NEXUS_BACKEND "${NEXUS_BACKEND}"
    NEXUS_COMPONENT_TARGETS "${nexus_component_targets}"
    NEXUS_STARTUP_SOURCE "${NEXUS_STARTUP_SOURCE}"
    NEXUS_SYSTEM_SOURCE "${NEXUS_SYSTEM_SOURCE}"
    NEXUS_SYSTEM_PRIVATE_INCLUDES "${NEXUS_SYSTEM_PRIVATE_INCLUDES}"
    NEXUS_SYSTEM_VENDOR_INCLUDES "${NEXUS_SYSTEM_VENDOR_INCLUDES}"
    NEXUS_SYSTEM_COMPILE_DEFINITIONS "${NEXUS_SYSTEM_COMPILE_DEFINITIONS}")
if(NEXUS_SOC_FAMILY STREQUAL "native")
    target_include_directories(nexus_platform PRIVATE "${NEXUS_SOURCE_DIR}/soc/native/drivers")
endif()
add_library(Nexus::Platform ALIAS nexus_platform)
option(NEXUS_BUILD_TESTS "Build maintained host behavior tests" ${PROJECT_IS_TOP_LEVEL})
option(NEXUS_BUILD_WORKLOAD "Build a minimal developer linkage workload" ${PROJECT_IS_TOP_LEVEL})
set(NEXUS_WORKLOAD "empty" CACHE STRING "Minimal resource fixture: empty/gpio/uart/spi")
if(NEXUS_BUILD_TESTS AND NEXUS_SOC_FAMILY STREQUAL "native")
    enable_testing()
    add_subdirectory(tests/contracts)
endif()
if(NEXUS_BUILD_WORKLOAD)
    nexus_add_firmware(nexus_firmware
        SOURCES "${NEXUS_SOURCE_DIR}/tools/measurement/workload.c")
    nexus_target_warnings(nexus_firmware STRICT)
    if(NOT NEXUS_WORKLOAD MATCHES "^(empty|gpio|uart|spi)$")
        message(FATAL_ERROR "Unknown minimal workload ${NEXUS_WORKLOAD}")
    endif()
    target_compile_definitions(nexus_firmware PRIVATE
        "NEXUS_WORKLOAD_${NEXUS_WORKLOAD}=1")
    if(NEXUS_WORKLOAD MATCHES "^(gpio|uart)$")
        include("${NEXUS_SOURCE_DIR}/cmake/platform/Workload.cmake")
        string(TOUPPER "${NEXUS_WORKLOAD}" workload_kind)
        set(NEXUS_WORKLOAD_${workload_kind}_ID "" CACHE STRING
            "Assembly-local typed factory ID used only by the workload")
        nexus_workload_identity("${NEXUS_CONFIG_DIR}" "${workload_kind}"
            "${NEXUS_WORKLOAD_${workload_kind}_ID}" workload_identity)
        target_compile_definitions(nexus_firmware PRIVATE
            "NEXUS_WORKLOAD_${workload_kind}_ID=${workload_identity}")
        if(NEXUS_WORKLOAD STREQUAL "gpio")
            string(REGEX REPLACE "^NX_GPIO_ID_" "" workload_gpio "${workload_identity}")
            target_compile_definitions(nexus_firmware PRIVATE
                "NEXUS_WORKLOAD_GPIO_MASK=NEXUS_${workload_gpio}_MASK")
        endif()
    endif()
endif()
if(NEXUS_IO_EVOLUTION_FIXTURE)
    include("${NEXUS_SOURCE_DIR}/tests/contracts/io_evolution_assembly/fixture.cmake")
endif()
message(STATUS "Nexus: ${NEXUS_EXACT_PART}/${NEXUS_BACKEND}, ${NEXUS_OPTIMIZATION}")
message(STATUS "Sole resolved configuration: ${NEXUS_CONFIG_DIR}/resolved.json")
