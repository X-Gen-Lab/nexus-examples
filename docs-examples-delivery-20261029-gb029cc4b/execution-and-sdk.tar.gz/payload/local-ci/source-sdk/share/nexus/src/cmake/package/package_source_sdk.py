#!/usr/bin/env python3
"""Prepare/verify a relocatable source SDK with fixed dependency provenance.

No compiler or effective build configuration is embedded as a reusable binary
ABI. This package is an unsigned source snapshot, not a promoted release.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tempfile

class SDKError(ValueError):
    pass


sys.dont_write_bytecode = True
SOURCE_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(SOURCE_ROOT))
try:
    from tools.maintenance.source_catalogue import (
        ALL_DEPENDENCIES, SOURCE_DEPENDENCIES, children, declared_modules,
        dependency, relative_path,
    )
    from tools.maintenance import (
        cmsis_device_lock, stm32f1_hal_lock, stm32f4_hal_lock,
        stm32g4_hal_lock, stm32h7_hal_lock, stm32u5_hal_lock,
        stm32g4_lock, threadx_lock, freertos_transport,
    )
    from tools.configure.metadata import load_policy, parse_json, snapshot
    from tools.configure import dependencies as configuration_dependencies
    from tools.configure.providers import descriptor as provider_descriptors
except ImportError as error:
    # Missing verifier modules are an incomplete SDK, including after an
    # attacker rehashes the payload map. Never accept a reduced checker graph.
    message = "missing required sources/licenses (source verifier dependencies)"
    if __name__ == "__main__":
        print("Source SDK rejected: " + message, file=sys.stderr)
        raise SystemExit(1) from error
    raise SDKError(message) from error

ROOT_FILES = {"CMakeLists.txt", "LICENSE", "README.md", "AGENTS.md", ".gitmodules",
              ".clang-format", ".editorconfig", ".clang-format-dirs"}
ROOT_DIRS = {"arch", "boards", "cmake", "dependencies", "core", "io", "os",
             "components", "drivers", "tools", "scripts", "soc"}
REQUIRED_DEPENDENCIES = tuple(item.path for item in SOURCE_DEPENDENCIES)
CMSIS_CORE_DIRECTORY = "vendors/arm/CMSIS_6"
CMSIS_CORE_REQUIRED_HEADERS = (
    "core_cm0.h", "core_cm0plus.h", "core_cm3.h", "core_cm4.h",
    "core_cm7.h", "core_cm23.h", "core_cm33.h", "core_cm55.h",
    "core_cm85.h", "cmsis_compiler.h", "cmsis_gcc.h", "cmsis_version.h",
    "m-profile/armv7m_mpu.h", "m-profile/armv8m_mpu.h",
    "m-profile/armv7m_cachel1.h", "m-profile/cmsis_gcc_m.h", "tz_context.h")
OFFICIAL_DRIVERS = (stm32f1_hal_lock, stm32f4_hal_lock, stm32g4_hal_lock,
                    stm32h7_hal_lock, stm32u5_hal_lock)
REQUIRED_FILES = (
    'io/include/nexus/io/usb_profile.h',
    'io/include/nexus/io/usb_activation.h',
    'io/src/mechanisms/usb_profile.c',
    'components/usb_control/CMakeLists.txt',
    'components/usb_control/include/nexus/components/usb_control.h',
    'components/usb_control/include/nexus/components/usb_descriptors.h',
    'components/usb_control/include/nexus/components/usb_acm.h',
    'components/usb_control/src/usb_control.c',
    'components/usb_control/src/usb_descriptors.c',
    'components/usb_control/src/usb_acm.c',
    "CMakeLists.txt", "LICENSE", ".gitmodules", "dependencies/toolchains.lock.json",
    "cmake/platform/CMSISCore.cmake",
    "dependencies/environment.lock.json", "core/include/nexus/core/request.h",
    "arch/include/nexus/arch/arch.h", "arch/arm/cortex_m/nx_arch_cortex_m.c",
    "arch/arm/cortex_m/private/compiler.h", "arch/native/nx_arch_native.c",
    "arch/include/nexus/arch/atomic.h", "arch/include/nexus/arch/features.h",
    "arch/include/nexus/arch/cache.h", "arch/include/nexus/arch/mpu.h",
    "arch/include/nexus/arch/security.h", "arch/arm/cortex_m/private/mechanisms.h",
    "arch/arm/cortex_m/nx_arch_cache.c", "arch/arm/cortex_m/nx_arch_mpu.c",
    "arch/arm/cortex_m/nx_arch_security.c",
    "arch/include/nexus/arch/cache_control.h",
    "arch/arm/cortex_m/nx_arch_cache_control.c",
    "arch/arm/cortex_m/private/cache_control.h",
    "arch/include/nexus/arch/nonsecure.h",
    "arch/arm/cortex_m/nx_arch_nonsecure.c",
    "arch/arm/cortex_m/private/nonsecure.h",
    "arch/include/nexus/arch/sleep.h", "arch/arm/cortex_m/nx_arch_sleep.c",
    "arch/arm/cortex_m/private/sleep.h",
    "core/include/nexus/core/memory.h",
    "core/include/nexus/core/request_observer.h", "core/src/request_observer.c",
    "io/include/nexus/io/stream_budget.h", "io/src/mechanisms/stream_budget.c",
    "io/include/nexus/io/diagnostic.h", "io/src/mechanisms/diagnostic.c",
    "components/owner_observer/CMakeLists.txt",
    "components/owner_observer/include/nexus/components/owner_observer.h",
    "components/owner_observer/src/owner_observer.c",
    "soc/gd32/gd32f470/memory_init.c", "soc/gd32/gd32f470/private/memory_init.h",
    "core/src/request.c", "io/include/nexus/io/fwd.h",
    "io/include/nexus/io/gpio.h",
    "io/include/nexus/io/uart.h", "os/freertos/include/FreeRTOSConfig.h",
    "boards/stm32f407_qiming_v31/board.json",
    "boards/stm32f407ve_sky_qingchun/board.json",
    "boards/gd32f470_liangshan/board.json",
    "cmake/platform/Firmware.cmake",
    "cmake/platform/TargetPolicy.cmake", "cmake/platform/Components.cmake",
    "tools/configure/matrix.py",
    "tools/configure/assemblies/catalogue.json",
    "tools/dev/dev.py", "tools/dev/presets.py", "tools/dev/process.py",
    "tools/dev/change_paths.py",
    "tools/dev/projects.py", "tools/dev/device.py", "tools/dev/timings.py",
    "tools/dev/cache.py", "tools/dev/dependencies.py",
    "tools/dev/qualification.py", "tools/dev/provenance.py",
    "tools/evidence/store.py",
    "tools/evidence/environment.py", "tools/evidence/recipe.py",
    "tools/maintenance/stm32_ll_lock.py", "cmake/platform/Workload.cmake",
    "dependencies/platform-compatibility.json",
    "os/freertos/tick.c", "os/freertos/include/nexus/os/tick.h",
    "os/CMakeLists.txt", "os/diagnostic.c",
    "os/include/nexus/os/diagnostic.h", "os/freertos/CMakeLists.txt",
    "os/freertos/freertos.c", "os/freertos/hooks.c",
    "os/freertos/include/nexus/os/freertos.h",
    "os/freertos/lowpower.c", "os/freertos/diagnostics.c",
    "os/freertos/include/nexus/os/lowpower.h",
    "os/freertos/include/nexus/os/freertos_diagnostics.h",
    "os/freertos/include/nexus/os/freertos_mpu.h",
    "os/freertos/include/nexus/os/freertos_mpu_gpio.h",
    "os/freertos/include/nexus/os/freertos_user.h",
    "os/freertos/include/nexus/os/secure_context.h",
    "os/freertos/mpu/prepare_port.py", "os/freertos/mpu/private.h",
    "os/freertos/mpu/task.c", "os/freertos/mpu/layout.c",
    "os/freertos/mpu/syscalls.c", "os/freertos/mpu/gpio.c",
    "os/freertos/mpu/guard.c", "os/freertos/mpu/guard_arm.c",
    "os/freertos/mpu/guard.h",
    "os/freertos/secure/Integration.cmake",
    "os/freertos/secure/CMakeLists.txt",
    "os/freertos/secure/config/FreeRTOSConfig.h",
    "os/freertos/secure/private/hardware.h",
    "os/freertos/secure/context.c", "os/freertos/secure/init.c",
    "cmake/platform/Runtime.cmake", "os/freertos/prepare_m7_integer.py",
    "tools/configure/assemblies/native.toml",
    "tools/configure/assemblies/qiming-baremetal-uart-dma.toml",
    "tools/configure/assemblies/sky-baremetal.toml",
    "tools/configure/assemblies/liangshan-baremetal.toml",
    "tools/measurement/workload.c",
    "ext/freertos/tasks.c", "ext/freertos/queue.c", "ext/freertos/list.c",
    "ext/freertos/LICENSE.md", "ext/freertos/.gitmodules",
    "vendors/arm/CMSIS_6/CMSIS/Core/Include/core_cm4.h", "vendors/arm/CMSIS_6/LICENSE",
    "vendors/st/cmsis_device_f4/Source/Templates/gcc/startup_stm32f407xx.s",
    "vendors/st/cmsis_device_f4/LICENSE.md",
    "vendors/gigadevice/gd32f4xx/Firmware/CMSIS/GD/GD32F4xx/Source/GCC/startup_gd32f450_470.S",
    "vendors/gigadevice/gd32f4xx/source.lock.json",
    "cmake/package/NexusConfig.cmake.in", "cmake/package/NexusConfigVersion.cmake.in",
    )
REQUIRED_FILES += tuple(item.path + "/" + item.notice
                        for item in ALL_DEPENDENCIES
                        if item.scope == "runtime"
                        and item.path + "/" + item.notice not in REQUIRED_FILES)
MANIFEST = ".nexus-source-sdk.json"
IO_EVOLUTION_VERIFICATION_FILES = tuple(
    "cmake/package/verification/io_evolution/" + name for name in (
        "consumers/h743-spi-dma.c", "consumers/h743-runtime-clock.c",
        "consumers/f407-handoff.c", "consumers/f407-i2s2-slave-tx.c",
        "consumers/u575-lpdma-copy.c",
        "consumers/u575-lptim1-lpbam.c", "consumers/u575-mpu-gpio.c",
        "consumers/h743-uart-continuous.c", "consumers/u575-lptim.c",
        "consumers/u575-rtc.c", "consumers/u575-retained-time.c", "consumers/u575-stop2.c", "consumers/user-io-async.c",
        "consumers/h743-uart-duplex-continuous.c",
        "h743-high-empty.toml", "h743-high-uart.toml",
        "u575-uart-gpdma.toml",
        "g474-can-fd-loopback.toml", "g474-can-fd-normal.toml",
        "g474-pwm-adc.toml", "boards/g474-fdcan/board.json",
        "boards/g474-pwm-adc/board.json", "consumers/h743-high.c",
        "consumers/u575-uart-gpdma.c", "consumers/g474-can-fd.c",
        "consumers/g474-pwm-adc.c",
        "g474-adc-group-regular-software.toml",
        "g474-adc-group-regular-timer.toml",
        "g474-adc-group-injected-software.toml",
        "g474-adc-group-injected-timer.toml",
        "boards/g474-adc-group/board.json", "consumers/g474-adc-group.c",
        "h743-uart-fifo.toml", "u575-uart-fifo.toml",
        "consumers/uart-fifo.c", "f407zg-eth-frames.toml",
        "gd470-eth-frames.toml", "boards/f407zg-eth-frames/board.json",
        "boards/gd470-eth-frames/board.json", "consumers/ethernet-frames.c",
        "h743-uart-rtscts.toml", "u575-uart-rtscts.toml",
        "g474-pwm-shared.toml", "boards/g474-pwm-shared/board.json",
        "consumers/g474-pwm-shared.c",
        "boards/g474-pin-states/board.json", "consumers/pin-states.c",
        "native-time-pair.toml", "native-time-empty.toml",
        "consumers/native-time-pair.c", "consumers/native-time-empty.c"))
REQUIRED_FILES += (
                   "tools/configure/assemblies/g474-pin-states.toml",
                   "tools/configure/assemblies/h743-high-peripherals.toml",
                   *IO_EVOLUTION_VERIFICATION_FILES)
REQUIRED_FILES += ("io/private/uart_fifo_impl.h",)
REQUIRED_FILES += (
    "io/include/nexus/io/ethernet_frames.h",
    "io/private/eth_frames_mac.h", "io/private/eth_frames_validation.h",
    "io/src/api/ethernet_frames.c", "io/src/controllers/eth_frames_mac.c",
    "soc/native/drivers/ethernet_frames.c", "soc/native/drivers/ethernet_frames.h",
    "soc/native/drivers/ethernet_frames_access.h")
REQUIRED_FILES += (
    "soc/stm32/stm32g474/reviews/adc-group.json",
    "io/include/nexus/io/adc_group.h", "io/src/api/adc_group.c")
# Required payload identity is separate from CMake's production source graph.
# Every exposed kernel profile must survive a rehashed omission attempt.
for _port in ("ARM_CM0", "ARM_CM3", "ARM_CM4F", "ARM_CM7/r0p1",
              "ARM_CM3_MPU", "ARM_CM4_MPU",
              "ARM_CM23_NTZ/non_secure", "ARM_CM33_NTZ/non_secure",
              "ARM_CM55_NTZ/non_secure", "ARM_CM85_NTZ/non_secure",
              "ARM_CM23/non_secure", "ARM_CM33/non_secure",
              "ARM_CM55/non_secure", "ARM_CM85/non_secure"):
    REQUIRED_FILES += tuple(f"ext/freertos/portable/GCC/{_port}/{name}"
                            for name in ("port.c", "portmacro.h"))
    if _port in {"ARM_CM0", "ARM_CM23_NTZ/non_secure",
                  "ARM_CM33_NTZ/non_secure", "ARM_CM55_NTZ/non_secure",
                  "ARM_CM85_NTZ/non_secure", "ARM_CM23/non_secure",
                  "ARM_CM33/non_secure", "ARM_CM55/non_secure",
                  "ARM_CM85/non_secure"}:
        REQUIRED_FILES += tuple(f"ext/freertos/portable/GCC/{_port}/{name}"
                                for name in ("portasm.c", "portasm.h"))
    if _port.endswith("/non_secure"):
        REQUIRED_FILES += (f"ext/freertos/portable/GCC/{_port}/portmacrocommon.h",)
    if _port in {"ARM_CM3_MPU", "ARM_CM4_MPU", "ARM_CM23_NTZ/non_secure",
                  "ARM_CM33_NTZ/non_secure", "ARM_CM55_NTZ/non_secure",
                  "ARM_CM85_NTZ/non_secure"}:
        REQUIRED_FILES += (f"ext/freertos/portable/GCC/{_port}/mpu_wrappers_v2_asm.c",)
for _core in (23, 33, 55, 85):
    REQUIRED_FILES += tuple(
        f"ext/freertos/portable/GCC/ARM_CM{_core}/secure/{name}"
        for name in ("secure_context_port.c", "secure_context.h",
                     "secure_init.h", "secure_port_macros.h"))
REQUIRED_FILES += tuple(f"ext/freertos/include/{name}" for name in (
    "FreeRTOS.h", "task.h", "queue.h", "list.h", "semphr.h", "portable.h",
    "projdefs.h", "stack_macros.h", "mpu_prototypes.h", "mpu_wrappers.h",
    "mpu_syscall_numbers.h", "deprecated_definitions.h", "timers.h",
    "event_groups.h", "stream_buffer.h"))
REQUIRED_FILES += (
    "dependencies/threadx.lock.json",
    "os/threadx/CMakeLists.txt",
    "os/threadx/Kernel.cmake", "os/threadx/threadx.c", "os/threadx/m4.c",
    "os/threadx/m4_vectors.S", "os/threadx/prepare_linux.py",
    "os/threadx/config/tx_user.h", "os/threadx/include/nexus/os/threadx.h")
# The reviewed lock remains the one ThreadX graph authority. Rehashed SDK
# omissions cannot remove required kernel payloads from a different file map.
_threadx_lock = parse_json((SOURCE_ROOT / "dependencies/threadx.lock.json").read_bytes())
threadx_lock.contract(_threadx_lock)
REQUIRED_FILES += tuple("ext/threadx/" + name for name in _threadx_lock["files"])
REQUIRED_FILES += ("ext/threadx/" + _threadx_lock["license"]["path"],)
REQUIRED_FILES += ("dependencies/stm32g4.lock.json",
                   )
_g4_lock = parse_json((SOURCE_ROOT / "dependencies/stm32g4.lock.json").read_bytes())
stm32g4_lock.contract(_g4_lock)
REQUIRED_FILES += tuple("vendors/st/cmsis_device_g4/" + name
                        for name in _g4_lock["files"])
REQUIRED_FILES += ("cmake/platform/STM32Official.cmake",)
for _official in OFFICIAL_DRIVERS:
    REQUIRED_FILES += (_official.LOCK_NAME,
                       "tools/maintenance/" + _official.__name__.split(".")[-1] + ".py")
    _official_lock = parse_json((SOURCE_ROOT / _official.LOCK_NAME).read_bytes())
    _official.contract(_official_lock)
    REQUIRED_FILES += tuple(_official.DIRECTORY + "/" + name
                            for name in _official_lock["files"])
# Complete declared platform surfaces must remain present after an attacker
# removes a payload and rehashes its file map. This is a required-source identity
# contract, not another build graph: CMake still owns every selected target.
# Explicit names make omissions fail closed; scanning an installed SDK would
# derive a reduced requirement from precisely the missing files being checked.
REQUIRED_FILES += (
    "core/CMakeLists.txt", "core/src/time.c", "core/src/fault.c",
    "core/src/stack_observation.c", "io/CMakeLists.txt",
    "tools/configure/assembly.schema.json",
    "cmake/platform/Configure.cmake", "cmake/platform/ControllerModes.cmake",
    "cmake/platform/Options.cmake", "cmake/platform/SDK.cmake",
    "tools/maintenance/dependency_proposals.py",
    "os/freertos/timebase_lowpower.c",
    "os/freertos/private/timebase_lowpower.h", "os/freertos/stack_snapshot.c",
    "os/freertos/include/nexus/os/freertos_stack.h",
    "os/threadx/private/irq_model.h", "os/threadx/private/m4_model.h",
    )
REQUIRED_FILES += tuple("core/include/nexus/core/" + name + ".h" for name in (
    "fault", "memory", "request", "request_observer", "stack_observation",
    "silicon", "status", "time"))
REQUIRED_FILES += ("core/src/silicon.c", "soc/stm32/common/stm32_identity.h")
REQUIRED_FILES += tuple("io/include/nexus/io/" + name + ".h" for name in (
    "adc", "adc_format", "adc_observer", "advanced_pwm", "can", "can_fd", "cycle_probe",
    "dma", "encoder",
    "ethernet",
    "exti", "flash", "gpio", "i2c", "i2c_bus_clear", "mdio", "native/model",
    "i2c_long", "observation", "pwm_adc", "pwm_group", "spi_transaction",
    "spi_dma_transaction", "spi_dma_owner_binding", "uart_format", "uart_word",
    "native/spi_dma_model", "spi", "stream", "stream_budget", "stream_profile", "timer",
    "timer_capture", "uart", "uart_rs485", "usb_device", "wake", "watchdog"))
REQUIRED_FILES += tuple("io/src/api/" + name + ".c" for name in (
    "adc", "advanced_pwm", "can", "can_fd", "encoder", "ethernet", "exti",
    "flash", "gpio", "i2c", "mdio", "pwm_adc", "pwm_group", "spi", "uart_word",
    "timer", "timer_capture", "uart", "usb_device", "watchdog"))
REQUIRED_FILES += tuple("io/src/controllers/" + name + ".c" for name in (
    "can_controller", "eth_mac", "usb_device_controller"))
REQUIRED_FILES += tuple("io/src/mechanisms/" + name + ".c" for name in (
    "adc_format", "adc_observer", "cycle_probe", "dma", "flash_region",
    "i2c_bus_clear", "i2c_long", "observation", "spi_transaction",
    "spi_dma_transaction", "spi_dma_sequence", "spi_dma_owner_binding",
    "stream", "stream_budget", "stream_profile", "uart_rs485", "wake"))
REQUIRED_FILES += tuple("io/private/" + name + ".h" for name in (
    "advanced_pwm_impl", "can_controller", "can_fd_impl", "eth_mac",
    "spi_dma_sequence", "spi_dma_sequence_owner",
    "timer_advanced_controller", "timer_capture_impl", "usb_device_controller"))
REQUIRED_FILES += tuple("soc/native/drivers/" + name + ".c" for name in (
    "adc", "can", "ethernet", "exti", "flash", "gpio", "i2c", "spi",
    "spi_async", "spi_dma_transaction", "stream", "time", "timer", "uart", "uart_word",
    "usb_device", "watchdog"))
REQUIRED_FILES += tuple("soc/native/drivers/" + name + ".h" for name in (
    "can", "can_access", "ethernet", "ethernet_access", "provider",
    "spi_dma_provider", "uart_word_provider",
    "usb_device", "usb_device_access"))
for _family in ("stm32f407", "gd32f470"):
    REQUIRED_FILES += tuple(provider_descriptors.source_directory(_family) + "/" + name for name in (
        "CMakeLists.txt", "system.c", "sleep.c", "timebase_lowpower.c",
        "usb_clock.c"))
    REQUIRED_FILES += tuple(provider_descriptors.source_directory(_family) + "/drivers/" + name + ".c"
                            for name in (
        "adc", "adc_continuous", "adc_stream", "advanced_pwm", "can",
        "ethernet", "exti", "flash", "gpio", "i2c", "i2c_async", "spi",
        "spi_dma", "timer", "timer_capture", "uart", "uart_dma",
        "uart_receive", "uart_duplex", "uart_stream", "uart_word", "usb_device", "watchdog"))
    REQUIRED_FILES += tuple(provider_descriptors.source_directory(_family) + "/private/" + _family + "_"
                            + name + ".h" for name in (
        "can", "dma", "eth", "i2c_async", "lowpower", "provider", "sleep",
        "timer_advanced", "uart_receive", "uart_word", "usb_clock", "usb_device"))
REQUIRED_FILES += ("soc/common/uart_control.h",)
REQUIRED_FILES += (
    "soc/stm32/stm32f407/private/stm32f407_system.h",
    "soc/stm32/stm32f407/private/stm32f407_stream.h",
    "soc/gd32/gd32f470/timebase.c", "soc/gd32/gd32f470/private/system.h",
    "soc/gd32/gd32f470/private/gd32f470_adc_stream.h",
    "soc/gd32/gd32f470/private/gd32f470_spi_dma.h",
    "soc/gd32/gd32f470/private/gd32f470_uart_stream.h",
    "soc/gd32/gd32f470/private/gd32f4xx_libopt.h", "soc/gd32/gd32f470/private/usb_conf.h")
REQUIRED_FILES += (
    "components/amp_ipc/CMakeLists.txt",
    "components/amp_ipc/src/amp_ipc.c",
    "components/amp_ipc/include/nexus/components/amp_ipc.h",
    "components/amp_ipc/include/nexus/components/amp_ipc_storage.h",
    "components/soc/stm32/stm32f407_handoff/CMakeLists.txt",
    "components/soc/stm32/stm32f407_handoff/include/nexus/components/stm32f407_handoff.h",
    "soc/stm32/stm32f407/handoff.c",
    "soc/stm32/stm32f407/private/stm32f407_handoff_hw.h",
    "cmake/package/verification/io_evolution/consumers/f407-handoff.c")
REQUIRED_FILES += (
    "components/user_io_broker/include/nexus/components/user_io_async.h",
    "components/user_io_broker/include/nexus/components/user_io_async_storage.h",
    "components/user_io_broker/src/user_io_async.c",
    "cmake/package/verification/io_evolution/consumers/user-io-async.c")
REQUIRED_FILES += (
    "components/soc/stm32/stm32u575_stop2/README.md",
    )
REQUIRED_FILES += (
    "io/include/nexus/io/frame_stream.h", "io/src/mechanisms/frame_stream.c",
    "components/soc/stm32/stm32h743_frame_dma2d/CMakeLists.txt",
    "components/soc/stm32/stm32h743_frame_dma2d/include/nexus/components/frame_dma2d.h",
    "components/soc/stm32/stm32h743_frame_dma2d/src/h743_frame_dma2d.c")
REQUIRED_FILES += (
    "components/i3c_controller/CMakeLists.txt",
    "components/i3c_controller/src/i3c_controller.c",
    "components/i3c_controller/include/nexus/components/i3c_controller.h",
    "components/i3c_controller/include/nexus/components/i3c_controller_storage.h")
for _component, _include, _private in (
        ("clock_domain", "nexus/components/clock_domain.h", "clock_domain_impl.h"),
        ("user_io_broker", "nexus/components/user_io_broker.h", "user_io_broker_impl.h"),
        ("dp83848", "nexus/dp83848/dp83848.h", None)):
    REQUIRED_FILES += tuple("components/" + _component + "/" + name for name in (
        "CMakeLists.txt", "src/" + _component + ".c", "include/" + _include))
    if _private is not None:
        REQUIRED_FILES += ("components/" + _component + "/private/" + _private,)
# The standalone Secure mechanism includes its complete private hardware port.
REQUIRED_FILES += tuple("soc/stm32/stm32u575/" + name for name in (
    "security.c", "private/stm32u575_security.h",
    "private/stm32u575_security_hw.h"))
# Public measurement references are part of the supported SDK input surface.
# A rehashed omission must not turn a complete SDK into a reduced profile set.
REQUIRED_FILES += tuple(
    f"tools/configure/assemblies/nucleo-{chip}-{backend}-{mode}.toml"
    for chip in ("h743", "u575")
    for backend in ("baremetal", "freertos")
    for mode in ("empty", "uart"))
# These shared inputs are opened by the default target graph even when no
# optional device is selected. Keep its exported components and actual resource
# observers complete as well; a rehashed map alone cannot prove their presence.
REQUIRED_FILES += (
    "arch/CMakeLists.txt", "cmake/toolchains/arm-gcc.cmake",
    "cmake/package/verify_consumers.py", "tools/release/transport.py",
    "components/CMakeLists.txt", "components/soc/CMakeLists.txt",
    "components/soc/stm32/CMakeLists.txt",
    "os/wait.c", "os/baremetal/notify.c", "os/native/native.c",
    "os/include/nexus/os/wait.h", "os/include/nexus/os/baremetal.h",
    "os/native/include/nexus/os/native.h",
    "tools/measurement/resources.py", "tools/measurement/retention.py",
    "tools/measurement/elf.py", "tools/evidence/common.py",
    "tools/evidence/identity.py")
REQUIRED_FILES += tuple("components/bus_owner/src/" + name + ".c" for name in (
    "bus_owner", "spi_owner", "spi_async_owner", "spi_dma_owner", "uart_owner"))
REQUIRED_FILES += tuple("components/bus_owner/include/nexus/components/" + name
                        + ".h" for name in (
    "bus_owner", "spi_owner", "spi_async_owner", "spi_dma_owner", "uart_owner"))
REQUIRED_FILES += (
    "components/bmp280/src/bmp280.c", "components/bmp280/src/spi_transport.c",
    "components/bmp280/include/nexus/components/bmp280.h",
    "components/bmp280/include/nexus/components/bmp280_spi.h",
    "components/log/src/log.c", "components/log/include/nexus/components/log.h",
    "components/modbus/src/modbus_rtu.c",
    "components/modbus/include/nexus/components/modbus_rtu.h")
REQUIRED_FILES += tuple("components/storage/src/" + name + ".c" for name in (
    "storage", "flash_storage", "file_flash"))
REQUIRED_FILES += tuple("components/storage/include/nexus/components/" + name
                        + ".h" for name in (
    "storage", "flash_storage", "file_flash"))
REQUIRED_FILES += ("components/mapped_storage/CMakeLists.txt",)
REQUIRED_FILES += tuple("components/mapped_storage/src/" + name + ".c"
                        for name in ("mapped_storage", "mapped_storage_owner",
                                     "native_mapped_storage"))
REQUIRED_FILES += tuple("components/mapped_storage/include/nexus/components/"
                        + name + ".h" for name in (
                            "mapped_storage", "mapped_storage_owner",
                            "native_mapped_storage"))
REQUIRED_FILES += tuple(CMSIS_CORE_DIRECTORY + "/CMSIS/Core/Include/" + name
                        for name in CMSIS_CORE_REQUIRED_HEADERS)
for _review in cmsis_device_lock.REVIEWED_DEVICES.values():
    REQUIRED_FILES += (_review["lock_name"],)
    REQUIRED_FILES += tuple(_review["directory"] + "/" + name
                            for name in sorted(_review["files"]))
# Reuse the generator closure; SDK-only entry points remain explicit above.
for _mode in ("platform", "runtime"):
    REQUIRED_FILES += tuple(configuration_dependencies.source_names(
        _mode, None, sdk=True))
for _descriptor in provider_descriptors.families():
    REQUIRED_FILES += _descriptor.fact_files + _descriptor.owned_payload
REQUIRED_FILES = tuple(dict.fromkeys(REQUIRED_FILES))
HEX40 = re.compile(r"[0-9a-f]{40}")
HEX64 = re.compile(r"[0-9a-f]{64}")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise SDKError("Duplicate identity key")
        result[key] = value
    return result


def safe_relative(name):
    if not isinstance(name, str):
        raise SDKError("Source paths must be strings")
    path = PurePosixPath(name)
    if (not name or "\\" in name or path.is_absolute() or ".." in path.parts
            or path.as_posix() != name or name == "."):
        raise SDKError("Unsafe source SDK path")
    return path


def regular(root, name):
    rel = safe_relative(name)
    path = root / Path(*rel.parts)
    for index in range(1, len(rel.parts) + 1):
        if (root / Path(*rel.parts[:index])).is_symlink():
            raise SDKError(f"Source SDK cannot follow symlinks: {name}")
    if not path.is_file():
        raise SDKError(f"Missing source SDK file: {name}")
    return path


def filesystem_identity(path):
    value = path.stat()
    return (value.st_dev, value.st_ino, value.st_mode, value.st_size,
            value.st_mtime_ns, value.st_ctime_ns)


def stable_file(root, name):
    """Bind content to one unchanged regular file throughout verification."""
    path = regular(root, name)

    def filesystem():
        return filesystem_identity(regular(root, name))

    before = filesystem()
    data = path.read_bytes()
    after = filesystem()
    if before != after or len(data) != after[3]:
        raise SDKError("Source SDK input changed during read: " + name)
    return data, (digest(data), after)


def git_environment(*, parent_index=False):
    """Read actual objects; only parent snapshot operations inherit its index."""
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith("GIT_")}
    environment.update({"GIT_CONFIG_NOSYSTEM": "1",
                        "GIT_CONFIG_GLOBAL": os.devnull,
                        "GIT_OPTIONAL_LOCKS": "0",
                        "GIT_NO_REPLACE_OBJECTS": "1"})
    if parent_index and "GIT_INDEX_FILE" in os.environ:
        environment["GIT_INDEX_FILE"] = os.environ["GIT_INDEX_FILE"]
    return environment


def git(root, *args, parent_index=False):
    result = subprocess.run(["git", "-c", "core.fsmonitor=false", "-C",
                             str(root), *args], capture_output=True,
                            env=git_environment(parent_index=parent_index))
    if result.returncode:
        raise SDKError("A complete Git checkout is required: " + result.stderr.decode(errors="replace").strip())
    return result.stdout


def tree_entries(root, revision="HEAD"):
    entries = {}
    for row in git(root, "ls-tree", "-r", "-z", revision).split(b"\0"):
        if not row:
            continue
        meta, name = row.split(b"\t", 1)
        mode, kind, oid = meta.decode().split()
        entries[name.decode()] = (mode, kind, oid)
    return entries


def dependency_snapshot(root, development_fixture=False):
    """Bind only explicit development dependencies to the real stage-0 index.

    A staged new or updated Gitlink is part of the nonpublishable worktree
    overlay. write-tree rejects conflicts and never stages or changes entries.
    Published sources continue to require the exact committed HEAD graph.
    """
    index = (git(root, "write-tree", parent_index=True).decode().strip()
             if development_fixture else None)
    return tree_entries(root, index if index is not None else "HEAD"), index


def verify_preparation_snapshot(root, revision, index):
    """Reject source or staged dependency changes across package preparation."""
    if git(root, "rev-parse", "HEAD").decode().strip() != revision:
        raise SDKError("Source commit changed while preparing the package")
    if index is not None and git(root, "write-tree", parent_index=True).decode().strip() != index:
        raise SDKError("Source index changed while preparing the development fixture")


def dependency_entries(root, dependency):
    """Redistribute only the locked source closure for reviewed imports."""
    entries = tree_entries(root / dependency)
    if dependency == CMSIS_CORE_DIRECTORY:
        prefix = "CMSIS/Core/Include/"
        required = {prefix + name for name in CMSIS_CORE_REQUIRED_HEADERS}
        required.add("LICENSE")
        if not required.issubset(entries):
            raise SDKError("CMSIS Core committed header/notice graph is incomplete")
        # Compiler and architecture headers contain recursive includes. Keep the
        # complete reviewed Include tree, never templates or RTOS components.
        entries = {name: entry for name, entry in entries.items()
                   if name == "LICENSE" or name.startswith(prefix)}
        if any(mode not in ("100644", "100755") or kind != "blob"
               for mode, kind, _ in entries.values()):
            raise SDKError("CMSIS Core payload must contain regular tracked files")
    elif dependency == "ext/threadx":
        raw, _ = snapshot(root / "dependencies/threadx.lock.json")
        lock = parse_json(raw)
        names = threadx_lock.contract(lock) | {lock["license"]["path"]}
        if not names.issubset(entries):
            raise SDKError("ThreadX committed source graph is incomplete")
        entries = {name: entries[name] for name in names}
    elif dependency == "vendors/st/cmsis_device_g4":
        raw, _ = snapshot(root / "dependencies/stm32g4.lock.json")
        names = stm32g4_lock.contract(parse_json(raw))
        if not names.issubset(entries):
            raise SDKError("G4 committed source graph is incomplete")
        entries = {name: entries[name] for name in names}
    elif dependency in {official.DIRECTORY for official in OFFICIAL_DRIVERS}:
        official = next(official for official in OFFICIAL_DRIVERS
                        if official.DIRECTORY == dependency)
        raw, _ = snapshot(root / official.LOCK_NAME)
        names = official.contract(parse_json(raw))
        if not names.issubset(entries):
            raise SDKError("Official committed source graph is incomplete: "
                           + dependency)
        entries = {name: entries[name] for name in names}
    else:
        for part, review in cmsis_device_lock.REVIEWED_DEVICES.items():
            if dependency != review["directory"]:
                continue
            raw, _ = snapshot(root / review["lock_name"])
            lock = parse_json(raw)
            names = cmsis_device_lock.contract(lock)
            if lock["selected_part"] != part or not names.issubset(entries):
                raise SDKError("Reviewed device committed source graph is incomplete")
            entries = {name: entries[name] for name in names}
            break
    return entries


def selected(name):
    # Only reviewed public smoke programs and their canonical software-reference
    # inputs belong in this namespace, including the explicit Native time pair.
    # Arbitrary host tests and private products do not.
    if name.startswith("cmake/package/verification/io_evolution/"):
        return name in IO_EVOLUTION_VERIFICATION_FILES
    # Historical audit archives belong to the repository, not the source SDK.
    if name.startswith("tools/testing/evidence/"):
        return False
    # Host frameworks and checkout presets do not become firmware dependencies.
    # The SDK excludes the root preset index, so its includes are not payload.
    # Reviewed host locks remain in provenance without host-only payloads.
    if name.startswith(("dependencies/source/", "cmake/testing/", "cmake/presets/")):
        return False
    return (name in ROOT_FILES or name.split("/", 1)[0] in ROOT_DIRS
            or any(name.startswith(directory + "/")
                   for directory in reviewed_import_directories()))


def snapshot_files(source, entries, development_fixture=False):
    """Select committed sources, or an explicit nonpublishable worktree view.

    Staged additions are tracked by the index but absent from HEAD and from
    Git's untracked list. Include both index and untracked paths only in the
    development overlay; publishable payloads retain committed-blob identity.
    """
    names = {name for name, (_, kind, _) in entries.items()
             if kind == "blob" and selected(name)}
    if development_fixture:
        names.update(name.decode() for name in git(
            source, "ls-files", "--cached", "--others", "--exclude-standard",
            "-z", parent_index=True).split(b"\0")
                     if name and selected(name.decode()))
    return names


def runtime_dependency_closure():
    """Expand only catalogue-owned descendants of required runtime sources."""
    records = {}

    def append(item):
        if item.path in records:
            raise SDKError("Duplicate dependency identity")
        if item.scope != "runtime":
            raise SDKError("Host-only dependency cannot enter the source SDK")
        records[item.path] = item
        for child in children(item.path):
            append(child)

    for path in REQUIRED_DEPENDENCIES:
        append(dependency(path))
    return records


def dependency_declarations(root, item, entries=None):
    """Bind recursive transport to reviewed declarations and committed links."""
    descendants = children(item.path)
    module_file = root / item.path / ".gitmodules"
    if descendants or module_file.exists() or module_file.is_symlink():
        try:
            declared_modules(regular(root, item.path + "/.gitmodules").read_bytes(),
                             parent=item.path)
        except ValueError as error:
            raise SDKError("Invalid recursive dependency declaration: " +
                           item.path) from error
    if entries is not None:
        links = {name for name, row in entries.items()
                 if row[1] == "commit"}
        if links != {relative_path(child) for child in descendants}:
            raise SDKError("Unregistered or missing recursive dependency Gitlink")


def dependency_records(root, entries):
    declared_modules(regular(root, ".gitmodules").read_bytes())
    closure = runtime_dependency_closure()
    records = []
    parent_entries = {None: entries}
    for path, item in closure.items():
        row = parent_entries[item.parent].get(relative_path(item))
        if not row or row[:2] != ("160000", "commit"):
            raise SDKError(f"Source commit has no required dependency Gitlink: {path}")
        checkout = root / safe_relative(path)
        if (checkout.resolve() != checkout or not (checkout / ".git").exists()
                or Path(git(checkout, "rev-parse", "--show-toplevel").decode()
                        .strip()).resolve() != checkout):
            raise SDKError(f"Initialize the pinned dependency before packaging: {path}")
        actual = git(checkout, "rev-parse", "HEAD").decode().strip()
        if actual != row[2]:
            raise SDKError(f"Initialize the pinned dependency before packaging: {path}")
        if git(checkout, "status", "--porcelain", "--untracked-files=all").strip():
            raise SDKError(f"Dependency checkout is dirty: {path}")
        origins = git(checkout, "config", "--local", "--get-all",
                      "remote.origin.url").decode().splitlines()
        if origins != [item.fetch_url]:
            raise SDKError(f"Dependency fetch origin is not approved: {path}")
        committed = tree_entries(checkout)
        dependency_declarations(root, item, committed)
        parent_entries[path] = committed
        if item.identifier == "freertos":
            freertos_transport.verify(root, selected_commit=actual,
                                      require_git=True)
        records.append({"path": path, "commit": actual,
                        "tree": git(checkout, "rev-parse", "HEAD^{tree}")
                        .decode().strip()})
    return records


def committed_blobs(root, entries):
    """Read Git blobs without checkout EOL/export transformations."""
    names = sorted(entries)
    request = "".join(entries[name][2] + "\n" for name in names).encode()
    result = subprocess.run(["git", "-c", "core.fsmonitor=false", "-C",
                             str(root), "cat-file", "--batch"],
                            input=request, capture_output=True,
                            env=git_environment())
    if result.returncode:
        raise SDKError("Cannot read the committed source objects")
    cursor = 0
    blobs = {}
    for name in names:
        end = result.stdout.find(b"\n", cursor)
        header = result.stdout[cursor:end].decode().split()
        if len(header) != 3 or header[0] != entries[name][2] or header[1] != "blob":
            raise SDKError("Source object identity is not a regular Git blob")
        size = int(header[2])
        cursor = end + 1
        data = result.stdout[cursor:cursor + size]
        cursor += size + 1
        if len(data) != size or hashlib.sha1(b"blob " + str(size).encode() + b"\0" + data).hexdigest() != entries[name][2]:
            raise SDKError("Committed source blob identity changed")
        blobs[name] = data
    if cursor != len(result.stdout):
        raise SDKError("Unexpected committed source object data")
    return blobs


def copy_file(source, output, name, data=None, executable=None):
    file = regular(source, name)
    if data is None:
        data = file.read_bytes()
    destination = output / safe_relative(name)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    destination.chmod(0o755 if (os.access(file, os.X_OK) if executable is None else executable) else 0o644)
    return digest(data)


def reviewed_import_directories():
    """Use maintained family declarations, never discover an installed file set."""
    return tuple(sorted({Path(item.import_lock).parent.as_posix()
                         for item in provider_descriptors.families()
                         if item.import_lock is not None}))


def validate_import_records(identity):
    """Require every reviewed import exactly once and bind its source tree."""
    records = identity["reviewed_imports"]
    expected = set(reviewed_import_directories())
    if (not isinstance(records, list) or len(records) != len(expected) or
            any(not isinstance(record, dict) or
                not isinstance(record.get("path"), str) or
                record.get("source_tree") != identity["source_tree"]
                for record in records) or
            {record["path"] for record in records} != expected):
        raise SDKError("Source SDK requires exact reviewed imports and owner tree")
    return records


def prepare(source, output, development_fixture=False):
    source = source.resolve()
    output = output.absolute()
    if output != output.resolve():
        raise SDKError("Source SDK output requires a canonical path without symlink or parent-directory aliases")
    if output.exists() or output.is_symlink():
        raise SDKError("Source SDK output must not already exist")
    if output.is_relative_to(source):
        raise SDKError("Prepare the relocatable source SDK outside its input checkout")
    if Path(git(source, "rev-parse", "--show-toplevel").decode().strip()).resolve() != source:
        raise SDKError("The source must be the actual Git repository root")
    revision = git(source, "rev-parse", "HEAD").decode().strip()
    source_tree = git(source, "rev-parse", "HEAD^{tree}").decode().strip()
    dirty = bool(git(source, "status", "--porcelain", "--untracked-files=normal",
                     parent_index=True).strip())
    if dirty and not development_fixture:
        raise SDKError("Publishable source SDK preparation rejects a dirty source checkout")
    entries = tree_entries(source)
    dependency_graph, index = dependency_snapshot(source, development_fixture)
    dependencies = dependency_records(source, dependency_graph)
    threadx_lock.verify(source / "ext/threadx", source / "dependencies/threadx.lock.json", "linux")
    stm32g4_lock.verify(source / "vendors/st/cmsis_device_g4",
                       source / "dependencies/stm32g4.lock.json")
    for official in OFFICIAL_DRIVERS:
        official.verify(source / official.DIRECTORY,
                        source / official.LOCK_NAME,
                        source / official.CMSIS_DIRECTORY)
    for review in cmsis_device_lock.REVIEWED_DEVICES.values():
        cmsis_device_lock.verify(source / review["directory"],
                                 source / review["lock_name"])
    sys.path.insert(0, str(source / "scripts/ci"))
    from vendor_import_identity import reviewed_import
    imports = [reviewed_import(source / directory, source)
               for directory in reviewed_import_directories()]
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=".nexus-source-sdk-", dir=output.parent))
    sdk = temporary / "share/nexus/src"
    sdk.mkdir(parents=True)
    files = {}
    try:
        names = snapshot_files(source, entries, development_fixture)
        source_blobs = {} if development_fixture else committed_blobs(source, {name: entries[name] for name in names})
        for name in sorted(names):
            entry = entries.get(name)
            if not (source / name).exists() and development_fixture:
                continue
            if entry and entry[0] not in ("100644", "100755"):
                raise SDKError("Source SDK requires regular Git blobs")
            files[name] = copy_file(source, sdk, name, source_blobs.get(name),
                                    entry[0] == "100755" if entry else None)
        for record in dependencies:
            dep = record["path"]
            dep_entries = dependency_entries(source, dep)
            blobs = committed_blobs(source / dep, {name: row for name, row in dep_entries.items() if row[1] == "blob"})
            for name, (mode, kind, blob) in dep_entries.items():
                if kind == "commit":
                    continue  # Copied from its own separately verified record.
                if mode not in ("100644", "100755"):
                    raise SDKError("Dependencies require regular tracked files")
                relative = dep + "/" + name
                files[relative] = copy_file(source, sdk, relative, blobs[name], mode == "100755")
        for name in REQUIRED_FILES:
            if name not in files:
                raise SDKError(f"Source SDK is incomplete: {name}")
        verify_preparation_snapshot(source, revision, index)
        manifest = {"schema": 1, "kind": "nexus-installed-source-sdk",
                    "source_revision": revision, "source_tree": source_tree,
                    "publishable": not development_fixture, "source_dirty": dirty,
                    "files_sha256": files, "dependencies": dependencies,
                    "reviewed_imports": imports,
                    "toolchains_lock_sha256": files["dependencies/toolchains.lock.json"],
                    "snapshot_sha256": digest(json.dumps(files, sort_keys=True, separators=(",", ":")).encode())}
        semantic_version = load_policy(sdk)["semantic_version"]
        config = (sdk / "cmake/package/NexusConfig.cmake.in").read_text().replace("@NEXUS_SDK_VERSION@", semantic_version)
        package = temporary / "lib/cmake/Nexus"
        package.mkdir(parents=True)
        (package / "NexusConfig.cmake").write_text(config)
        version = (sdk / "cmake/package/NexusConfigVersion.cmake.in").read_text().replace("@NEXUS_SDK_VERSION@", semantic_version)
        (package / "NexusConfigVersion.cmake").write_text(version)
        manifest["package_files_sha256"] = {
            "lib/cmake/Nexus/NexusConfig.cmake": digest((package / "NexusConfig.cmake").read_bytes()),
            "lib/cmake/Nexus/NexusConfigVersion.cmake": digest((package / "NexusConfigVersion.cmake").read_bytes())}
        (sdk / MANIFEST).write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
        verify(sdk)
        verify_preparation_snapshot(source, revision, index)
        if dependency_records(source, dependency_graph) != dependencies:
            raise SDKError("Source dependencies changed while preparing the package")
        temporary.rename(output)
    except BaseException:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
    return manifest


def verify(root):
    root = root.absolute()
    if root.is_symlink() or not root.is_dir() or root.resolve() != root:
        raise SDKError("Installed source SDK root must be a regular directory")
    directories = {root, *(path for path in root.rglob("*") if path.is_dir())}
    directory_identity = {path: filesystem_identity(path) for path in directories}
    raw_identity, first_identity = stable_file(root, MANIFEST)
    checked = {(root, MANIFEST): first_identity}
    identity = json.loads(raw_identity, object_pairs_hook=object_pairs)
    fields = {"schema", "kind", "source_revision", "source_tree", "publishable", "source_dirty",
              "files_sha256", "dependencies", "reviewed_imports", "toolchains_lock_sha256", "snapshot_sha256",
              "package_files_sha256"}
    if set(identity) != fields or identity["schema"] != 1 or identity["kind"] != "nexus-installed-source-sdk":
        raise SDKError("Unsupported installed source SDK identity")
    if any(not isinstance(identity[key], str) or not HEX40.fullmatch(identity[key]) for key in ("source_revision", "source_tree")):
        raise SDKError("Invalid source Git identity")
    if any(type(identity[key]) is not bool for key in ("publishable", "source_dirty")):
        raise SDKError("Invalid source SDK provenance flags")
    if identity["publishable"] and identity["source_dirty"]:
        raise SDKError("A dirty source SDK cannot be publishable")
    files = identity["files_sha256"]
    if not isinstance(files, dict) or not files:
        raise SDKError("Source SDK requires a complete file identity")
    # Missing mandatory names already disqualify the manifest. Reject before
    # reading payload bytes; accepted manifests still undergo every check below.
    if any(name not in files for name in REQUIRED_FILES):
        raise SDKError("Installed source SDK is missing required sources/licenses")
    for name, expected in files.items():
        if not isinstance(expected, str) or not HEX64.fullmatch(expected):
            raise SDKError("Invalid source SDK file digest")
        _, actual_file = stable_file(root, name)
        checked[root, name] = actual_file
        if actual_file[0] != expected:
            raise SDKError(f"Source SDK file identity changed: {name}")
    actual = {path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file() or path.is_symlink()}
    if actual != set(files) | {MANIFEST}:
        raise SDKError("Installed source SDK has missing or additional files")
    if identity["snapshot_sha256"] != digest(json.dumps(files, sort_keys=True, separators=(",", ":")).encode()):
        raise SDKError("Source snapshot file-map identity changed")
    if identity["toolchains_lock_sha256"] != files["dependencies/toolchains.lock.json"]:
        raise SDKError("Toolchain lock identity differs from packaged source")
    if root.parts[-3:] != ("share", "nexus", "src"):
        raise SDKError("Relocate the complete installed SDK prefix, not its source subtree")
    prefix = root.parents[2]
    directory_identity.update((path, filesystem_identity(path)) for path in (
        prefix, prefix / "share", prefix / "share/nexus", prefix / "lib",
        prefix / "lib/cmake", prefix / "lib/cmake/Nexus"))
    package_files = identity["package_files_sha256"]
    expected_exports = {"lib/cmake/Nexus/NexusConfig.cmake", "lib/cmake/Nexus/NexusConfigVersion.cmake"}
    if not isinstance(package_files, dict) or set(package_files) != expected_exports:
        raise SDKError("Source SDK requires its exported CMake package identity")
    for name, expected in package_files.items():
        if not isinstance(expected, str) or not HEX64.fullmatch(expected):
            raise SDKError("Exported CMake package identity changed")
        _, exported = stable_file(prefix, name)
        checked[prefix, name] = exported
        if exported[0] != expected:
            raise SDKError("Exported CMake package identity changed")
    records = identity["dependencies"]
    if not isinstance(records, list) or not records:
        raise SDKError("Source SDK requires dependency commit identities")
    paths = set()
    for record in records:
        if not isinstance(record, dict) or set(record) != {"path", "commit", "tree"}:
            raise SDKError("Invalid source SDK dependency record")
        path = str(safe_relative(record["path"]))
        if path in paths or any(not isinstance(record[key], str) or not HEX40.fullmatch(record[key]) for key in ("commit", "tree")):
            raise SDKError("Invalid or duplicate source SDK dependency identity")
        if not any(name.startswith(path + "/") for name in files):
            raise SDKError("Dependency provenance has no packaged source")
        paths.add(path)
    closure = runtime_dependency_closure()
    if paths != set(closure):
        raise SDKError("Source SDK dependency set differs from the reviewed catalogue")
    declared_modules(regular(root, ".gitmodules").read_bytes())
    for item in closure.values():
        dependency_declarations(root, item)
    freertos = next(record for record in records
                    if record["path"] == "ext/freertos")
    # Package preparation proves the Git parent/tree contract. Without Git,
    # verify only exported materials and their selected identity. Consumers
    # authenticate the archive externally before executing SDK-owned tools.
    freertos_transport.verify(root, selected_commit=freertos["commit"],
                              require_git=False)
    threadx = next(record for record in records if record["path"] == "ext/threadx")
    threadx_lock.verify(root / "ext/threadx", root / "dependencies/threadx.lock.json",
                        "linux", packaged_commit=threadx["commit"])
    g4 = next(record for record in records
              if record["path"] == "vendors/st/cmsis_device_g4")
    stm32g4_lock.verify(root / "vendors/st/cmsis_device_g4",
                       root / "dependencies/stm32g4.lock.json",
                       packaged_commit=g4["commit"])
    for official in OFFICIAL_DRIVERS:
        driver = next(record for record in records
                      if record["path"] == official.DIRECTORY)
        cmsis = next(record for record in records
                     if record["path"] == official.CMSIS_DIRECTORY)
        official.verify(root / official.DIRECTORY,
                        root / official.LOCK_NAME,
                        root / official.CMSIS_DIRECTORY,
                        packaged_commit=driver["commit"],
                        packaged_cmsis_commit=cmsis["commit"])
    for review in cmsis_device_lock.REVIEWED_DEVICES.values():
        matching = [record for record in records
                    if record["path"] == review["directory"]]
        if len(matching) != 1:
            raise SDKError("Source SDK lacks its exact reviewed device dependency")
        cmsis_device_lock.verify(root / review["directory"],
                                 root / review["lock_name"],
                                 packaged_commit=matching[0]["commit"])
    sys.path.insert(0, str(root / "scripts/ci"))
    from vendor_import_identity import validate_import_record
    from verify_vendor_source import verify as verify_vendor_import
    for record in validate_import_records(identity):
        imported = root / record["path"]
        notices = {item["path"]: regular(imported, item["path"]).read_bytes()
                   for item in record.get("notices", [])}
        lock_contents = regular(imported, "source.lock.json").read_bytes()
        validate_import_record(record, lock_contents, notices,
                               identity["source_revision"])
        # A rehashed package map cannot replace the reviewed upstream closure.
        # Reuse the same byte verifier used during preparation, then close its
        # auxiliary file set against the recorded origin and license notices.
        verify_vendor_import(imported)
        expected = {"source.lock.json", *notices,
                    *(item["path"] for item in parse_json(lock_contents)["files"])}
        actual_import = {path.relative_to(imported).as_posix()
                         for path in imported.rglob("*")
                         if path.is_file() or path.is_symlink()}
        if actual_import != expected:
            raise SDKError("Source SDK contains files outside the reviewed import")
    # An external verifier can take time. Reject late rewrites, same-content
    # replacements, chmod and file-set changes rather than returning an old
    # proof for the current SDK. Every hash and filesystem identity is retained.
    for (directory, name), first in checked.items():
        try:
            _, final = stable_file(directory, name)
        except (SDKError, OSError) as error:
            raise SDKError("Source SDK changed during verification: " + name) from error
        if final != first:
            raise SDKError("Source SDK changed during verification: " + name)
    final_files = {path.relative_to(root).as_posix() for path in root.rglob("*")
                   if path.is_file() or path.is_symlink()}
    if final_files != actual:
        raise SDKError("Source SDK file set changed during verification")
    # Close the final content sweep as well: a file checked early in that sweep
    # may have changed while a later file was being read. This is an observed
    # stability window; callers still need an immutable SDK during actual use.
    for (directory, name), (_, first_filesystem) in checked.items():
        if filesystem_identity(regular(directory, name)) != first_filesystem:
            raise SDKError("Source SDK input changed during closing proof: " + name)
    final_directories = {root, *(path for path in root.rglob("*") if path.is_dir())}
    if final_directories != directories or any(
            filesystem_identity(path) != first
            for path, first in directory_identity.items()):
        raise SDKError("Source SDK directories changed during verification")
    return identity


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--development-fixture", action="store_true")
    parser.add_argument("--verify", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.verify:
            if args.source or args.output or args.development_fixture:
                raise SDKError("Verification cannot also prepare a source package")
            result = verify(args.verify)
        elif args.source and args.output:
            result = prepare(args.source, args.output, args.development_fixture)
        else:
            raise SDKError("Use --source/--output to prepare, or --verify to inspect")
    except (SDKError, OSError, ValueError, TypeError, KeyError) as exc:
        print(f"Source SDK rejected: {exc}", file=sys.stderr)
        return 1
    print(json.dumps({"kind": "nexus_source_sdk_summary", "sdk_kind": result["kind"],
                      "source_revision": result["source_revision"],
                      "publishable": result["publishable"], "files": len(result["files_sha256"]),
                      "snapshot_sha256": result["snapshot_sha256"]}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
