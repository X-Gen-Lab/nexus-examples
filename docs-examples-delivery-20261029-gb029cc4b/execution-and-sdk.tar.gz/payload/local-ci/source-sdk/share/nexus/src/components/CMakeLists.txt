# CMakeLists.txt
# Explicit common component targets; unreferenced components do not enter images.
# Author: Nexus Team
add_library(nexus_bus_owner STATIC bus_owner/src/bus_owner.c)
target_include_directories(nexus_bus_owner PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}/bus_owner/include")
target_link_libraries(nexus_bus_owner PUBLIC nexus_core nexus_os_wait PRIVATE nexus_owned_warnings nexus_build_options)
add_library(nexus_spi_owner STATIC bus_owner/src/spi_owner.c)
target_link_libraries(nexus_spi_owner PUBLIC nexus_bus_owner nexus_io PRIVATE nexus_owned_warnings nexus_build_options)
add_library(nexus_spi_async_owner STATIC bus_owner/src/spi_async_owner.c)
target_link_libraries(nexus_spi_async_owner PUBLIC nexus_bus_owner nexus_io
    PRIVATE nexus_owned_warnings nexus_build_options)
add_library(nexus_spi_dma_owner STATIC bus_owner/src/spi_dma_owner.c)
target_link_libraries(nexus_spi_dma_owner PUBLIC nexus_bus_owner nexus_io
    PRIVATE nexus_arch nexus_owned_warnings nexus_build_options)
add_library(nexus_uart_owner STATIC bus_owner/src/uart_owner.c)
target_link_libraries(nexus_uart_owner PUBLIC nexus_bus_owner nexus_io PRIVATE nexus_owned_warnings nexus_build_options)

add_library(nexus_bmp280 STATIC bmp280/src/bmp280.c)
target_include_directories(nexus_bmp280 PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}/bmp280/include")
target_link_libraries(nexus_bmp280 PUBLIC nexus_core PRIVATE nexus_owned_warnings nexus_build_options)
add_library(nexus_bmp280_spi STATIC bmp280/src/spi_transport.c)
target_link_libraries(nexus_bmp280_spi PUBLIC nexus_bmp280 nexus_io PRIVATE nexus_owned_warnings nexus_build_options)

add_library(nexus_log STATIC log/src/log.c)
target_include_directories(nexus_log PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}/log/include")
target_link_libraries(nexus_log PUBLIC nexus_core
    PRIVATE nexus_arch nexus_owned_warnings nexus_build_options)
add_library(nexus_storage STATIC storage/src/storage.c)
target_include_directories(nexus_storage PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}/storage/include")
target_link_libraries(nexus_storage PUBLIC nexus_abi_options PRIVATE nexus_owned_warnings nexus_build_options)
add_library(nexus_modbus STATIC modbus/src/modbus_rtu.c)
target_include_directories(nexus_modbus PUBLIC "${CMAKE_CURRENT_SOURCE_DIR}/modbus/include")
target_link_libraries(nexus_modbus PUBLIC nexus_abi_options PRIVATE nexus_owned_warnings nexus_build_options)
add_library(nexus_flash_storage STATIC storage/src/flash_storage.c)
target_link_libraries(nexus_flash_storage PUBLIC nexus_storage nexus_io PRIVATE nexus_owned_warnings nexus_build_options)
if(NEXUS_SOC_FAMILY STREQUAL "native")
    add_library(nexus_file_flash STATIC storage/src/file_flash.c)
    target_link_libraries(nexus_file_flash PUBLIC nexus_storage PRIVATE nexus_owned_warnings nexus_build_options)
endif()

add_library(Nexus::BusOwner ALIAS nexus_bus_owner)
add_library(Nexus::SpiOwner ALIAS nexus_spi_owner)
add_library(Nexus::SPIAsyncOwner ALIAS nexus_spi_async_owner)
add_library(Nexus::SPIDMATransactionOwner ALIAS nexus_spi_dma_owner)
add_library(Nexus::UARTOwner ALIAS nexus_uart_owner)
add_library(Nexus::BMP280 ALIAS nexus_bmp280)
add_library(Nexus::BMP280SPI ALIAS nexus_bmp280_spi)
add_library(Nexus::Log ALIAS nexus_log)
add_library(Nexus::Storage ALIAS nexus_storage)
add_library(Nexus::FlashStorage ALIAS nexus_flash_storage)
add_library(Nexus::ModbusRTU ALIAS nexus_modbus)
if(TARGET nexus_file_flash)
    add_library(Nexus::FileFlash ALIAS nexus_file_flash)
endif()
add_subdirectory(owner_observer)
add_subdirectory(dp83848)

add_subdirectory(clock_domain)
add_subdirectory(user_io_broker)

add_subdirectory(usb_control)

add_subdirectory(mapped_storage)
add_subdirectory(amp_ipc)
add_subdirectory(soc)


add_subdirectory(i3c_controller)
