# CMake generated Testfile for 
# Source directory: /dev/shm/nexus-examples-final
# Build directory: /dev/shm/nexus-examples-final/build/native-debug
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[shared_spi_two_devices]=] "/dev/shm/nexus-examples-final/build/native-debug/bin/shared_spi_runtime")
set_tests_properties([=[shared_spi_two_devices]=] PROPERTIES  LABELS "native;example" TIMEOUT "10" _BACKTRACE_TRIPLES "/dev/shm/nexus-examples-final/CMakeLists.txt;46;add_test;/dev/shm/nexus-examples-final/CMakeLists.txt;0;")
add_test([=[stream_slow_consumer]=] "/dev/shm/nexus-examples-final/build/native-debug/bin/stream_recovery")
set_tests_properties([=[stream_slow_consumer]=] PROPERTIES  LABELS "native;example" TIMEOUT "10" _BACKTRACE_TRIPLES "/dev/shm/nexus-examples-final/CMakeLists.txt;47;add_test;/dev/shm/nexus-examples-final/CMakeLists.txt;0;")
add_test([=[uart_owner_shutdown]=] "/dev/shm/nexus-examples-final/build/native-debug/bin/uart_owner_runtime")
set_tests_properties([=[uart_owner_shutdown]=] PROPERTIES  LABELS "native;example" TIMEOUT "10" _BACKTRACE_TRIPLES "/dev/shm/nexus-examples-final/CMakeLists.txt;48;add_test;/dev/shm/nexus-examples-final/CMakeLists.txt;0;")
add_test([=[platform_static_ports]=] "/dev/shm/nexus-examples-final/build/native-debug/bin/platform_reference")
set_tests_properties([=[platform_static_ports]=] PROPERTIES  LABELS "native;example" TIMEOUT "10" _BACKTRACE_TRIPLES "/dev/shm/nexus-examples-final/CMakeLists.txt;49;add_test;/dev/shm/nexus-examples-final/CMakeLists.txt;0;")
add_test([=[sensor_explicit_spi]=] "/dev/shm/nexus-examples-final/build/native-debug/bin/sensor_spi")
set_tests_properties([=[sensor_explicit_spi]=] PROPERTIES  LABELS "native;example" TIMEOUT "10" _BACKTRACE_TRIPLES "/dev/shm/nexus-examples-final/CMakeLists.txt;50;add_test;/dev/shm/nexus-examples-final/CMakeLists.txt;0;")
add_test([=[persistent_journal]=] "/dev/shm/nexus-examples-final/build/native-debug/bin/journal" "/dev/shm/nexus-examples-final/build/native-debug/journal.dat")
set_tests_properties([=[persistent_journal]=] PROPERTIES  LABELS "native;example" TIMEOUT "10" _BACKTRACE_TRIPLES "/dev/shm/nexus-examples-final/CMakeLists.txt;51;add_test;/dev/shm/nexus-examples-final/CMakeLists.txt;0;")
add_test([=[protocol_authorized_registers]=] "/dev/shm/nexus-examples-final/build/native-debug/bin/modbus_registers")
set_tests_properties([=[protocol_authorized_registers]=] PROPERTIES  LABELS "native;example" TIMEOUT "10" _BACKTRACE_TRIPLES "/dev/shm/nexus-examples-final/CMakeLists.txt;52;add_test;/dev/shm/nexus-examples-final/CMakeLists.txt;0;")
subdirs("nexus")
subdirs("tests")
