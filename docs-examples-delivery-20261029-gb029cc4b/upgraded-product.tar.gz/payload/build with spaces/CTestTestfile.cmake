# CMake generated Testfile for 
# Source directory: /dev/shm/nexus-user-upgrade-7590b2d4/product with spaces
# Build directory: /dev/shm/nexus-user-upgrade-7590b2d4/build with spaces
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[starter_application]=] "/dev/shm/nexus-user-upgrade-7590b2d4/build with spaces/bin/nexus_starter")
set_tests_properties([=[starter_application]=] PROPERTIES  TIMEOUT "10" _BACKTRACE_TRIPLES "/dev/shm/nexus-user-upgrade-7590b2d4/product with spaces/CMakeLists.txt;22;add_test;/dev/shm/nexus-user-upgrade-7590b2d4/product with spaces/CMakeLists.txt;0;")
subdirs("nexus-sdk")
