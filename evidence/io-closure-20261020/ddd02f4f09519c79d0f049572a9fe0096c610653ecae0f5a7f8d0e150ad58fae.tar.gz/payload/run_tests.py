"""Run all 25 methods against one isolated production variant; no compiler runs."""
from pathlib import Path
import importlib.util
import resource
import sys
import unittest
resource.setrlimit(resource.RLIMIT_AS,(70*1024*1024,70*1024*1024))
base=Path('/tmp/nexus-examples-github-gate-20261020')
sys.path.insert(0,'/tmp/nexus-examples-completion-20261020/scripts')
variant=sys.argv[1]
spec=importlib.util.spec_from_file_location('tdd_gate',base/variant/'scripts/tdd_gate.py')
gate=importlib.util.module_from_spec(spec)
sys.modules['tdd_gate']=gate
spec.loader.exec_module(gate)
spec=importlib.util.spec_from_file_location('jobs_complete_test_tdd_gate',base/'after/scripts/test_tdd_gate.py')
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
suite=unittest.defaultTestLoader.loadTestsFromModule(module)
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
