# UART FIFO development evidence / UART FIFO 开发证物

This unsigned bundle retains the selected original bytes, failures and execution
receipts. It is not a complete software candidate or physical qualification.
The final ordinary commit gate and exact-head CI run remain separate evidence.

- The workload's historical 20-case RED/GREEN used the recorded earlier SDK
  source. Its final namespace comment was later normalized to repository style.
  Those records do not establish integration with a different SDK revision.
- The gate's final 24-method Python fixture run passes; its mocked build commands
  and 15 synthetic Google cases do not establish real 67-case Native execution.
- The real C11 contract run records five failing application subtests before the
  explicit language-standard change, followed by a passing complete method.
- Two fresh public-only standalone ARM builds use the exact e434303 Nexus source
  and existing H743/U575 baremetal FIFO assemblies. Their ELF/BIN/map/resource
  reports, compile commands, generated configuration and actual receipts are
  included. Flash usage is 10,676/10,276 bytes respectively; reserved RAM is
  8,664 bytes each, including MSP 2,048 and heap 0. These are full-application
  link costs, not measured latency, stack high-water or isolated platform costs.
- The initial tools preflight failed because its PATH and dependency checkout
  were incomplete. It is preserved as an environmental failure, not semantic
  test-driven-development RED evidence.
- The workflow draft's original two-method RED/GREEN is retained. The final
  source drops the test that repeated workflow command text; it keeps the
  existing report-retention regression and verifies the actual ARM builds in CI.
- Seventeen maintained presets are preserved. The independent FIFO application
  adds no preset, private provider, authored assembly or automatic station action.
- Dependency preparation used exact immutable cached vendor sources, with
  independent destination Git metadata and shared immutable file inodes. The
  original source validator passed 17 presets and 16 recursive dependencies.

本归档保留真实原始失败、源码和执行回执，未签名，不授予整个软件候选版或实板资格。
历史 20 项宿主测试、24 项工具夹具测试和两次真实 ARM 构建具有各自明确的源码范围；
不能互相替代，也不能把合成报告或构建成功解释为设备执行。最终提交门禁和精确提交
CI 单独提供整轮验证。保留 17 个 presets；实板 HIL 始终为 not_executed。
