"""Suggested addition to ReferencePlatformTests; add `import re` to its file.

Assumes the new shell step calls its isolated build directory `output` and the
SDK fixture selector `reference`; these names match the proposed CI block.
No repository files were changed and no test/compiler was executed to prepare
this suggestion.
"""


def test_fifo_arm_ci_uses_only_maintained_baremetal_routes_and_retains_evidence(self):
    workflow = yaml.load((ROOT / ".github/workflows/ci.yml").read_text(),
                         Loader=yaml.BaseLoader)
    steps = workflow["jobs"]["arm"]["steps"]
    selected = [step for step in steps
                if "cmake -S apps/uart_fifo_acquisition" in step.get("run", "")]
    self.assertEqual(len(selected), 1)
    step = selected[0]
    expected = {f"stm32-{family}-nucleo-baremetal": family
                for family in REFERENCE_BOARDS}
    condition = step["if"].strip().removeprefix("${{").removesuffix("}}").strip()
    terms = [re.fullmatch(r"\s*matrix\.preset\s*==\s*'([^']+)'\s*", term)
             for term in condition.split("||")]
    self.assertEqual(len(terms), len(expected))
    self.assertTrue(all(terms), "FIFO scope must be exactly explicit preset equalities")
    self.assertEqual({term.group(1) for term in terms}, set(expected))
    self.assertEqual(step["env"]["PRESET"], "${{ matrix.preset }}")
    commands = step["run"]
    self.assertIn('case "$PRESET" in', commands)
    routes = dict(re.findall(
        r"^\s*(stm32-[^ )]+)\)\s+reference=([a-z0-9]+)\s*;;\s*$",
        commands, re.MULTILINE))
    self.assertEqual(routes, expected)
    self.assertIn('output="build/$PRESET/uart-fifo"', commands)
    self.assertIn('cmake -S apps/uart_fifo_acquisition -B "$output"', commands)
    self.assertIn('-DNEXUS_SOURCE="$GITHUB_WORKSPACE/external/nexus"', commands)
    self.assertIn('-DCMAKE_TOOLCHAIN_FILE="$GITHUB_WORKSPACE/external/nexus/'
                  'cmake/toolchains/arm-gcc.cmake"', commands)
    self.assertIn('-DNEXUS_ASSEMBLY_FILE="$GITHUB_WORKSPACE/external/nexus/'
                  'cmake/package/verification/io_evolution/${reference}-uart-fifo.toml"',
                  commands)
    self.assertIn('cmake --build "$output"', commands)
    self.assertNotIn("--preset", commands)
    for name in ("configure", "build"):
        self.assertIn(f'tee "$output/{name}.log"', commands)
    artifact = next(step for step in steps if step.get("name") ==
                    "Retain firmware and static validation evidence")
    retained = set(artifact["with"]["path"].splitlines())
    prefix = "build/${{ matrix.preset }}/uart-fifo/"
    for suffix in ("configure.log", "build.log", "CMakeCache.txt",
                   "compile_commands.json", "nexus/generated/*", "bin/*"):
        self.assertIn(prefix + suffix, retained)
