"""Replay the selected workflow regression; no CMake or compiler invocation."""
from pathlib import Path
import importlib.util
import sys
import unittest
base=Path('/tmp/nexus-examples-google-aggregate-jobs-20261020/integration-review')
sys.path.insert(0,'/tmp/nexus-examples-completion-20261020/scripts')
spec=importlib.util.spec_from_file_location('workflow_retention_review',base/'after/scripts/test_reference_platforms.py')
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
module.ROOT=base/sys.argv[1]
suite=unittest.TestSuite([module.ReferencePlatformTests('test_ci_builds_every_arm_preset_and_retains_reference_google_evidence')])
result=unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
