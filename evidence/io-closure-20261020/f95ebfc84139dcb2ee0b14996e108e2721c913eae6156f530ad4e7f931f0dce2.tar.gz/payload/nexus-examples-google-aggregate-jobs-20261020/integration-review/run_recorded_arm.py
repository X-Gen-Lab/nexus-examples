from pathlib import Path
import json,os,resource,sys
sys.path.insert(0,'/tmp/nexus-quality-20261019')
from tools.dev.process import run
resource.setrlimit(resource.RLIMIT_AS,(70*1024*1024,70*1024*1024))
base=Path('/tmp/nexus-examples-google-aggregate-jobs-20261020/integration-review')
mode,variant=sys.argv[1:]
result=run([sys.executable,'-B',str(base/'run_tests_arm.py'),variant],cwd=base,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},log=base/'evidence'/(mode+'.log'),timeout=30,stage='examples-workflow-fifo-arm-'+mode)
print(json.dumps({'mode':mode,'exit_code':result.returncode,'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}))
raise SystemExit(result.returncode)
