from pathlib import Path
p=Path('/tmp/nexus-examples-google-aggregate-20261020/after/scripts/test_tdd_gate.py');s=p.read_text();s=s.replace('''        self.mutate = None
''','''        self.mutate = None
        self.google_specs = {}
        for index, name in enumerate(
                name for name in gate.EXPECTED_CTEST_NAMES
                if name.endswith("_google")):
            output = ("google-execution" if name == "owner_lifecycle_google"
                      else name + "-execution")
            self.google_specs[name] = {
                "binary": self.root / "build/native-debug/tests" / (name + "_test"),
                "output": self.root / "build/native-debug/tests" / output,
                "cases": index + 1,
            }
        self.secondary = next(name for name in self.google_specs
                              if name != "owner_lifecycle_google")
''')
start=s.index('    def execute(self, root, arguments, environment, log):')
end=s.index('    def run_gate(self, paths=',start)
s=s[:start]+'''    def execute(self, root, arguments, environment, log):
        """Mock commands only; real SDK validators parse each produced XML."""
        self.commands.append((arguments, environment))
        log.write_text("Synthetic subprocess-boundary fixture.\\n")
        if "test_repository.py" in str(arguments[1]):
            if self.mode == "sdk_dirty":
                raise ValueError("Nexus source has uncommitted changes")
            report = Path(arguments[arguments.index("--report") + 1])
            report.write_text(json.dumps({
                "kind": "example-source-dependency-identity",
                "candidate_validation": self.mode == "candidate",
                "source_revision_matches_lock": self.mode != "wrong_lock",
                "example_gitlink_verified": True,
                "nexus_revision": self.sdk_revision, "nexus_tree": "b" * 40,
            }))
        elif "build.py" in str(arguments[1]):
            if self.mode != "missing":
                skipped = '<skipped/>' if self.mode == "skip" else ""
                names = list(gate.EXPECTED_CTEST_NAMES)
                names.extend(name for name in self.google_specs
                             if name not in names)
                if self.mode == "partial":
                    names = names[:-1]
                cases = "".join('<testcase name="' + name + '">' + skipped +
                                "</testcase>" for name in names)
                self.write("build/native-debug/ctest-results.xml",
                           "<testsuite>" + cases + "</testsuite>")
            for name, spec in self.google_specs.items():
                binary, output = spec["binary"], spec["output"]
                self.write(str(binary.relative_to(self.root)), "fixture binary\\n")
                case_names = ["CompleteCase" + (str(i) if i else "")
                              for i in range(spec["cases"])]
                listing = "Fixture.\\n" + "".join("  " + case + "\\n"
                                                for case in case_names)
                self.write(str((output / "discovery.log").relative_to(self.root)),
                           listing)
                testcases = "".join(
                    '<testcase classname="Fixture" name="' + case +
                    '" status="run" result="completed"/>' for case in case_names)
                report = output / "google-results.xml"
                self.write(str(report.relative_to(self.root)),
                           '<testsuites name="AllTests"><testsuite name="Fixture">'
                           + testcases + '</testsuite></testsuites>')
                if name == self.secondary:
                    if self.mode == "secondary_missing":
                        report.unlink()
                    elif self.mode == "secondary_stale":
                        os.utime(output / "discovery.log", ns=(1, 1))
                    elif self.mode == "secondary_wrong_identity":
                        (output / "discovery.log").write_text(
                            listing.replace("CompleteCase", "OtherCase"))
                    elif self.mode == "secondary_skipped":
                        report.write_text(report.read_text().replace(
                            'status="run" result="completed"',
                            'status="notrun" result="suppressed"'))
                    elif self.mode == "secondary_symlink":
                        retained = self.root / "retained.xml"
                        retained.write_text(report.read_text())
                        report.unlink()
                        report.symlink_to(retained)
            if self.mode == "stale":
                os.utime(self.root / "build/native-debug/ctest-results.xml",
                         ns=(1, 1))
            if self.mode == "wrong_google":
                self.write("build/native-debug/tests/google-execution/discovery.log",
                           "Fixture.\\n  OtherCase\\n")
            if self.mutate:
                self.mutate()
        elif arguments[0] == "ctest":
            names = list(gate.EXPECTED_CTEST_NAMES)
            names.extend(name for name in self.google_specs if name not in names)
            if self.mode == "filtered" and "--preset" not in arguments:
                names.append("additional_actual_test")
            entries = []
            for name in names:
                entry = {"name": name, "properties": []}
                if name in self.google_specs:
                    spec = self.google_specs[name]
                    entry["properties"] = [
                        {"name": "LABELS", "value": ["native", "GoogleTest"]}]
                    entry["command"] = [
                        "/python", "-B", str(self.root / "scripts/run_google.py"),
                        "--nexus-source", str(self.root / "external/nexus"),
                        "--binary", str(spec["binary"]),
                        "--output", str(spec["output"])]
                    if name == self.secondary:
                        if self.mode == "duplicate_output":
                            entry["command"][-1] = str(
                                self.google_specs["owner_lifecycle_google"]["output"])
                        elif self.mode == "duplicate_binary":
                            entry["command"][-3] = str(
                                self.google_specs["owner_lifecycle_google"]["binary"])
                        elif self.mode == "missing_label":
                            entry["properties"] = []
                        elif self.mode == "repeated_output_argument":
                            entry["command"].extend(["--output", str(spec["output"])])
                entries.append(entry)
            return json.dumps({"tests": entries})
        return ""

''' + s[end:]
anchor='''    def test_unstaged_and_untracked_behavior_rejected_before_execution(self):
'''
new='''    def test_all_labelled_google_programs_are_reported_without_extra_execution(self):
        report = self.run_gate()
        programs = report.get("google_programs", [])
        self.assertEqual(len(programs), len(self.google_specs))
        self.assertEqual({program["ctest_name"] for program in programs},
                         set(self.google_specs))
        aggregate = report.get("google_aggregate", {})
        self.assertEqual(aggregate.get("programs"), len(self.google_specs))
        self.assertEqual(aggregate.get("passed"),
                         sum(spec["cases"] for spec in self.google_specs.values()))
        self.assertEqual(report["google"]["passed"], 1)
        self.assertEqual(len(self.commands), 5)

    def test_an_added_actual_google_label_is_aggregated_without_a_name_list(self):
        self.google_specs["new_actual_contract"] = {
            "binary": self.root / "build/native-debug/tests/new-contract",
            "output": self.root / "build/native-debug/tests/new-execution",
            "cases": 2,
        }
        report = self.run_gate()
        self.assertIn("new_actual_contract",
                      {p["ctest_name"] for p in report.get("google_programs", [])})
        self.assertEqual(report.get("google_aggregate", {}).get("programs"),
                         len(self.google_specs))

    def test_secondary_google_missing_stale_skipped_or_wrong_identity_rejects(self):
        for mode in ("secondary_missing", "secondary_stale",
                     "secondary_skipped", "secondary_wrong_identity"):
            with self.subTest(mode=mode):
                self.mode = mode
                with self.assertRaises((ValueError, OSError)):
                    self.run_gate()
                self.assertFalse((self.root / "build/native-debug/tdd/execution.json")
                                 .exists())

    def test_secondary_google_symlink_is_not_followed_as_execution_evidence(self):
        self.mode = "secondary_symlink"
        with self.assertRaisesRegex(ValueError, "symlink"):
            self.run_gate()
        self.assertIn("AllTests", (self.root / "retained.xml").read_text())

    def test_ambiguous_catalogue_google_identity_or_output_is_rejected(self):
        for mode in ("duplicate_output", "duplicate_binary", "missing_label",
                     "repeated_output_argument"):
            with self.subTest(mode=mode):
                self.mode = mode
                with self.assertRaises(ValueError):
                    self.run_gate()

    def test_cli_prints_the_aggregate_instead_of_only_the_legacy_program(self):
        report = {"google": {"passed": 1},
                  "google_aggregate": {"passed": 15, "programs": 5}}
        with mock.patch.object(gate, "run_gate", return_value=report), \\
                mock.patch("builtins.print") as output:
            self.assertEqual(gate.main([]), 0)
        self.assertIn("15 GoogleTest cases", output.call_args.args[0])
        self.assertIn("5 programs", output.call_args.args[0])

'''+anchor
asserts=anchor in s;assert asserts;s=s.replace(anchor,new)
compile(s,str(p),'exec');p.write_text(s)
