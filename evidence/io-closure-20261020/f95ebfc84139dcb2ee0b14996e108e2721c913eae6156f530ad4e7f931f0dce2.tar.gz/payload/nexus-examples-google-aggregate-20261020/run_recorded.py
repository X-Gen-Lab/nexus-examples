from pathlib import Path
import json,os,resource,sys
sys.path.insert(0,'/tmp/nexus-quality-20261019')
from tools.dev.process import run
resource.setrlimit(resource.RLIMIT_AS,(70*1024*1024,70*1024*1024))
base=Path('/tmp/nexus-examples-google-aggregate-20261020')
mode,variant=sys.argv[1:]
r=run([sys.executable,'-B',str(base/'run_tests.py'),variant],cwd=base,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},log=base/'evidence'/(mode+'.log'),timeout=180,stage='examples-complete-test-tdd-gate-'+mode)
print(json.dumps({'mode':mode,'exit_code':r.returncode,'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss}))
raise SystemExit(r.returncode)
