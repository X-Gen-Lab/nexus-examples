/* Exact resolved physical layout; no product reservation. */
ENTRY(Reset_Handler)
PHDRS {
    flash PT_LOAD FLAGS(5);
    data PT_LOAD FLAGS(6);
    ram PT_LOAD FLAGS(6);
    stack PT_LOAD FLAGS(6);

}
MEMORY {
    FLASH (rx) : ORIGIN = 0x08000000, LENGTH = 2097152
    RAM (rwx) : ORIGIN = 0x24000000, LENGTH = 524288

}
__nx_flash_start = ORIGIN(FLASH);
__nx_flash_end = ORIGIN(FLASH) + LENGTH(FLASH);
__nx_flash_live_start = ORIGIN(FLASH);
__nx_flash_image_load_start = ORIGIN(FLASH);
_estack = ORIGIN(RAM) + LENGTH(RAM);
_sp = _estack;
_Min_Stack_Size = 2048;
_Min_Heap_Size = 0;
__nx_msp_start = _estack - _Min_Stack_Size;
__nx_msp_end = _estack;
__nx_resolved_sha256_0 = 0xde029b73;
__nx_resolved_sha256_1 = 0x5e1a2511;
__nx_resolved_sha256_2 = 0xca4b92bd;
__nx_resolved_sha256_3 = 0x976560c0;
__nx_resolved_sha256_4 = 0x7699cef0;
__nx_resolved_sha256_5 = 0xfb8bb53b;
__nx_resolved_sha256_6 = 0xc5a70d30;
__nx_resolved_sha256_7 = 0x37f797c3;
SECTIONS {
    .isr_vector : { KEEP(*(.isr_vector)) KEEP(*(.vectors)) } > FLASH :flash
    .text : { *(.text*) *(.rodata*) KEEP(*(.init)) KEEP(*(.fini)) } > FLASH :flash
    .ARM.extab : { *(.ARM.extab*) } > FLASH :flash
    .ARM.exidx : { __exidx_start = .; *(.ARM.exidx*) __exidx_end = .; } > FLASH :flash
    .preinit_array : { PROVIDE_HIDDEN(__preinit_array_start = .); KEEP(*(.preinit_array*)) PROVIDE_HIDDEN(__preinit_array_end = .); } > FLASH :flash
    .init_array : { PROVIDE_HIDDEN(__init_array_start = .); KEEP(*(SORT(.init_array.*))) KEEP(*(.init_array*)) PROVIDE_HIDDEN(__init_array_end = .); } > FLASH :flash
    .fini_array : { PROVIDE_HIDDEN(__fini_array_start = .); KEEP(*(SORT(.fini_array.*))) KEEP(*(.fini_array*)) PROVIDE_HIDDEN(__fini_array_end = .); } > FLASH :flash
    __nx_flash_live_end = .;
    .nx_itcm_unselected : { *(.nx_itcm_data .nx_itcm_data.*) *(.bss.nx_itcm_noinit .bss.nx_itcm_noinit.*) *(.bss.nx_itcm .bss.nx_itcm.*) } > RAM :ram
    ASSERT(SIZEOF(.nx_itcm_unselected) == 0, "memory region is not selected")
    .nx_dtcm_unselected : { *(.nx_dtcm_data .nx_dtcm_data.*) *(.bss.nx_dtcm_noinit .bss.nx_dtcm_noinit.*) *(.bss.nx_dtcm .bss.nx_dtcm.*) } > RAM :ram
    ASSERT(SIZEOF(.nx_dtcm_unselected) == 0, "memory region is not selected")
    .nx_sram1_unselected : { *(.nx_sram1_data .nx_sram1_data.*) *(.bss.nx_sram1_noinit .bss.nx_sram1_noinit.*) *(.bss.nx_sram1 .bss.nx_sram1.*) } > RAM :ram
    ASSERT(SIZEOF(.nx_sram1_unselected) == 0, "memory region is not selected")
    .nx_sram2_unselected : { *(.nx_sram2_data .nx_sram2_data.*) *(.bss.nx_sram2_noinit .bss.nx_sram2_noinit.*) *(.bss.nx_sram2 .bss.nx_sram2.*) } > RAM :ram
    ASSERT(SIZEOF(.nx_sram2_unselected) == 0, "memory region is not selected")
    .nx_sram3_unselected : { *(.nx_sram3_data .nx_sram3_data.*) *(.bss.nx_sram3_noinit .bss.nx_sram3_noinit.*) *(.bss.nx_sram3 .bss.nx_sram3.*) } > RAM :ram
    ASSERT(SIZEOF(.nx_sram3_unselected) == 0, "memory region is not selected")
    .nx_sram4_unselected : { *(.nx_sram4_data .nx_sram4_data.*) *(.bss.nx_sram4_noinit .bss.nx_sram4_noinit.*) *(.bss.nx_sram4 .bss.nx_sram4.*) } > RAM :ram
    ASSERT(SIZEOF(.nx_sram4_unselected) == 0, "memory region is not selected")
    .nx_backup-sram_unselected : { *(.nx_backup-sram_data .nx_backup-sram_data.*) *(.bss.nx_backup-sram_noinit .bss.nx_backup-sram_noinit.*) *(.bss.nx_backup-sram .bss.nx_backup-sram.*) } > RAM :ram
    ASSERT(SIZEOF(.nx_backup-sram_unselected) == 0, "memory region is not selected")
    _sidata = LOADADDR(.data);
    .data : ALIGN(4) { . = ALIGN(4); _sdata = .; *(.data*) . = ALIGN(4); _edata = .; } > RAM AT> FLASH :data
    __nx_flash_image_load_end = LOADADDR(.data) + SIZEOF(.data);
    .bss (NOLOAD) : AT(ADDR(.bss)) { . = ALIGN(4); _sbss = .; *(.bss*) *(COMMON) . = ALIGN(4); _ebss = .; } > RAM :ram
    .reserved (NOLOAD) : AT(ADDR(.reserved)) { . = ALIGN(8); __heap_start = .; __nx_heap_start = .; . += _Min_Heap_Size; __heap_end = .; __nx_heap_end = .; } > RAM :ram
    .msp __nx_msp_start (NOLOAD) : AT(__nx_msp_start) { . += _Min_Stack_Size; } > RAM :stack
    PROVIDE(end = _ebss);
    PROVIDE(_end = _ebss);
    ASSERT(_ebss + _Min_Heap_Size <= _estack - _Min_Stack_Size, "RAM stack/heap overlap")
}
