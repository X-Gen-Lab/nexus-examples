/**
 * \file            bindings.c
 * \brief           Generated fixed typed hardware construction.
 * \author          Nexus Team
 * \version         1.0.0
 * \date            2026-10-09
 * \copyright       Copyright (c) 2026 Nexus Team
 */
#include "nexus_config.h"
#include "nexus_bindings.h"
#include "nexus_factory.h"
#include "nexus/arch/arch.h"
#ifndef NX_PLATFORM_REGISTER_WRITE
#define NX_PLATFORM_REGISTER_WRITE(reg, value) ((reg) = (uint32_t)(value))
#endif
#ifndef NX_PLATFORM_PRIORITY_WRITE
#define NX_PLATFORM_PRIORITY_WRITE(reg, value) ((reg) = (uint8_t)(value))
#endif
#include "stm32u575_provider.h"
#include "stm32u575_uart_fifo.h"
void _init(void);
void _fini(void);
/** \brief C runtime hooks; constructors use .init_array. */
void _init(void) {}
void _fini(void) {}
static bool s_nx_platform_started;
static size_t s_nx_platform_initialized;
static uint32_t s_nx_platform_gpio_clocks_added;
static uint32_t s_nx_peripheral_apb2enr_added;
static struct {
    uint32_t mode, type, speed, pull, af0, af1, odr;
    bool captured; } s_nx_gpioa_lease;
static nx_result_t restore_gpioa(void) {
    if (!s_nx_gpioa_lease.captured) { return NX_SUCCESS; }
    NX_U575_WRITE(&GPIOA->MODER, (NX_U575_READ(&GPIOA->MODER) & ~3932160u) | 3932160u);
    nx_arch_dsb();
    if ((NX_U575_READ(&GPIOA->MODER) & 3932160u) != 3932160u) { return NX_ERROR_IO; }
    NX_U575_WRITE(&GPIOA->BSRR, s_nx_gpioa_lease.odr | ((1536u & ~s_nx_gpioa_lease.odr) << 16u));
    nx_arch_dsb();
    if ((NX_U575_READ(&GPIOA->ODR) & 1536u) != s_nx_gpioa_lease.odr) { return NX_ERROR_IO; }
    NX_U575_WRITE(&GPIOA->AFR[1], (NX_U575_READ(&GPIOA->AFR[1]) & ~4080u) | s_nx_gpioa_lease.af1);
    nx_arch_dsb();
    if ((NX_U575_READ(&GPIOA->AFR[1]) & 4080u) != s_nx_gpioa_lease.af1) { return NX_ERROR_IO; }
    NX_U575_WRITE(&GPIOA->OTYPER, (NX_U575_READ(&GPIOA->OTYPER) & ~1536u) | s_nx_gpioa_lease.type);
    nx_arch_dsb();
    if ((NX_U575_READ(&GPIOA->OTYPER) & 1536u) != s_nx_gpioa_lease.type) { return NX_ERROR_IO; }
    NX_U575_WRITE(&GPIOA->OSPEEDR, (NX_U575_READ(&GPIOA->OSPEEDR) & ~3932160u) | s_nx_gpioa_lease.speed);
    nx_arch_dsb();
    if ((NX_U575_READ(&GPIOA->OSPEEDR) & 3932160u) != s_nx_gpioa_lease.speed) { return NX_ERROR_IO; }
    NX_U575_WRITE(&GPIOA->PUPDR, (NX_U575_READ(&GPIOA->PUPDR) & ~3932160u) | s_nx_gpioa_lease.pull);
    nx_arch_dsb();
    if ((NX_U575_READ(&GPIOA->PUPDR) & 3932160u) != s_nx_gpioa_lease.pull) { return NX_ERROR_IO; }
    NX_U575_WRITE(&GPIOA->MODER, (NX_U575_READ(&GPIOA->MODER) & ~3932160u) | s_nx_gpioa_lease.mode);
    nx_arch_dsb();
    if ((NX_U575_READ(&GPIOA->MODER) & 3932160u) != s_nx_gpioa_lease.mode) { return NX_ERROR_IO; }
    s_nx_gpioa_lease.captured = false;
    return NX_SUCCESS;
}
static nx_stm32u575_uart_fifo_state_t s_nx_port_console;
static const nx_uart_port_t s_nx_face_console = {
    &nx_stm32u575_uart_fifo_ops, &s_nx_port_console
};
const nx_uart_port_t* const nx_binding_console = &s_nx_face_console;
static const nx_stm32u575_uart_fifo_profile_t
s_nx_fifo_profile_console = {
    .rx_threshold = 2u, .tx_threshold = 2u,
    .rx_budget = 2u,
    .tx_budget = 3u
};
static uint8_t s_nx_rx_console[64];
static nx_result_t prepare_console(void) {
    if (s_nx_port_console.uart.retained || s_nx_port_console.uart.initialized || s_nx_port_console.uart.active != NULL || s_nx_port_console.uart.wake != NULL || s_nx_port_console.uart.wake_publishers != 0u) { return NX_ERROR_BUSY; }
    s_nx_port_console.uart.registers = USART1;
    s_nx_port_console.uart.rx_storage = s_nx_rx_console;
    s_nx_port_console.uart.rx_capacity = 64u;
    s_nx_port_console.uart.baud = 115200u;
    s_nx_port_console.uart.irq = USART1_IRQn;
    s_nx_port_console.uart.profile = NX_UART_RX_BYTES;
    s_nx_port_console.uart.irq_policy = (nx_irq_policy_t){ NX_IRQ_KERNEL_NONE, 126u, 4u, 0u };
    nx_result_t status = nx_stm32u575_usart1_pins_prepare();
    if (status != NX_SUCCESS) { return status; }
    s_nx_port_console.fifo = &s_nx_fifo_profile_console;
    return nx_stm32u575_uart_fifo_initialize(&s_nx_port_console, 4000000u, 1000000u);
}
void USART1_IRQHandler(void);
/** \brief Selected bounded FIFO RX/TX budgets. */
void USART1_IRQHandler(void) { nx_stm32u575_uart_fifo_irq(&s_nx_port_console); }
/** \brief Reset only the supplied call-scoped output. */
static void nx_platform_diagnostic_reset(nx_platform_diagnostic_t* diagnostic) {
    if (diagnostic != NULL) {
        *diagnostic = (nx_platform_diagnostic_t){
            NX_PLATFORM_PHASE_NONE, SIZE_MAX,
            NX_PLATFORM_PHASE_NONE, SIZE_MAX };
    }
}
/** \brief Select the primary or cleanup path without replacing errors. */
static void nx_platform_diagnostic_phase(nx_platform_diagnostic_t* diagnostic,
                                         bool cleanup, nx_platform_phase_t phase,
                                         size_t controller_index) {
    if (diagnostic == NULL) { return; }
    if (cleanup) {
        diagnostic->cleanup_phase = phase;
        diagnostic->cleanup_controller_index = controller_index;
    } else {
        diagnostic->phase = phase;
        diagnostic->controller_index = controller_index;
    }
}
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup);
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic);
/** \brief Stop only the initialized selected interfaces. */
nx_result_t nx_platform_stop(void) {
    return nx_platform_stop_impl(NULL, false);
}
/** \brief Add caller-owned metadata to the same stop path. */
nx_result_t nx_platform_stop_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    return nx_platform_stop_impl(diagnostic, false);
}
/** \brief Shared stop body preserves primary failure metadata. */
static nx_result_t nx_platform_stop_impl(nx_platform_diagnostic_t* diagnostic, bool cleanup) {
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) { return NX_ERROR_CONTEXT; }
    if (s_nx_platform_initialized >= 1u) {
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_CONTROLLER, 0u);
        nx_result_t status_0 = nx_uart_port_stop(&s_nx_face_console);
        if (status_0 != NX_SUCCESS) { return status_0; }
        s_nx_platform_initialized = 0u;
    }
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    if (s_nx_platform_started) {
        nx_result_t gpio_a = restore_gpioa();
        if (gpio_a != NX_SUCCESS) { return gpio_a; }
        NX_U575_WRITE(&RCC->APB2ENR, NX_U575_READ(&RCC->APB2ENR) & ~s_nx_peripheral_apb2enr_added);
        nx_arch_dsb();
        if ((NX_U575_READ(&RCC->APB2ENR) & s_nx_peripheral_apb2enr_added) != 0u) { return NX_ERROR_IO; }
        s_nx_peripheral_apb2enr_added = 0u;
        NX_U575_WRITE(&RCC->AHB2ENR1, NX_U575_READ(&RCC->AHB2ENR1) & ~s_nx_platform_gpio_clocks_added);
        nx_arch_dsb();
        if ((NX_U575_READ(&RCC->AHB2ENR1) & s_nx_platform_gpio_clocks_added) != 0u) { return NX_ERROR_IO; }
        s_nx_platform_gpio_clocks_added = 0u;
        nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
        nx_result_t system = nx_stm32u575_system_stop(&g_nx_stm32u575_system, 1000000u);
        if (system != NX_SUCCESS) { return system; }
    }
    s_nx_platform_started = false;
    s_nx_platform_initialized = 0u;
    nx_platform_diagnostic_phase(diagnostic, cleanup, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return NX_SUCCESS;
}
/** \brief Start explicit hardware only; rollback retains error facts. */
nx_platform_start_result_t nx_platform_start(void) {
    return nx_platform_start_impl(NULL);
}
/** \brief Add caller-owned metadata to the same startup path. */
nx_platform_start_result_t nx_platform_start_diagnosed(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_diagnostic_reset(diagnostic);
    nx_platform_start_result_t result = nx_platform_start_impl(diagnostic);
    if (diagnostic != NULL && result.primary == NX_SUCCESS) {
        nx_platform_diagnostic_reset(diagnostic);
    } else if (diagnostic != NULL && result.cleanup != NX_SUCCESS &&
               diagnostic->cleanup_phase == NX_PLATFORM_PHASE_NONE) {
        diagnostic->cleanup_phase = NX_PLATFORM_PHASE_SYSTEM;
        diagnostic->cleanup_controller_index = SIZE_MAX;
    }
    return result;
}
/** \brief One shared startup implementation, without stored observers. */
static nx_platform_start_result_t nx_platform_start_impl(nx_platform_diagnostic_t* diagnostic) {
    nx_platform_start_result_t result = { NX_SUCCESS, NX_SUCCESS, 0u };
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTEXT, SIZE_MAX);
    if (nx_arch_in_isr() || nx_arch_irq_is_masked() || !nx_arch_is_privileged()) {
        result.primary = NX_ERROR_CONTEXT; return result; }
    if (s_nx_platform_started) { result.primary = NX_ERROR_STATE; return result; }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_SYSTEM, SIZE_MAX);
    result.primary = nx_stm32u575_system_preflight(&g_nx_stm32u575_system);
    if (result.primary != NX_SUCCESS) { return result; }
    if ((NX_U575_READ(&RCC->APB2ENR) & RCC_APB2ENR_USART1EN) != 0u) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    if ((NX_U575_READ(&RCC->CCIPR1) & RCC_CCIPR1_USART1SEL) != 0u) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    if (!NX_U575_IRQ_AVAILABLE((IRQn_Type)USART1_IRQn)) {
        result.primary = NX_ERROR_BUSY; return result;
    }
    if ((NX_U575_READ(&RCC->AHB2ENR1) & RCC_AHB2ENR1_GPIOAEN) != 0u) {
        uint32_t mode = NX_U575_READ(&GPIOA->MODER);
        if (((mode >> 18u) & 3u) != 0u && ((mode >> 18u) & 3u) != 3u) {
            result.primary = NX_ERROR_BUSY; return result;
        }
        if (((mode >> 20u) & 3u) != 0u && ((mode >> 20u) & 3u) != 3u) {
            result.primary = NX_ERROR_BUSY; return result;
        }
        if ((NX_U575_READ(&GPIOA->LCKR) & 1536u) != 0u) {
            result.primary = NX_ERROR_BUSY; return result;
        }
    }
    nx_stm32u575_start_result_t system = nx_stm32u575_system_start(&g_nx_stm32u575_system, 1000000u);
    if (system.primary != NX_SUCCESS) {
        result.primary = system.primary;
        result.cleanup = system.cleanup;
        result.remaining_effects = system.remaining_effects;
        s_nx_platform_started = result.remaining_effects != 0u;
        return result;
    }
    s_nx_platform_started = true;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_RESOURCES, SIZE_MAX);
    s_nx_platform_gpio_clocks_added = ~NX_U575_READ(&RCC->AHB2ENR1) & (RCC_AHB2ENR1_GPIOAEN);
    s_nx_peripheral_apb2enr_added = ~NX_U575_READ(&RCC->APB2ENR) & (RCC_APB2ENR_USART1EN);
    s_nx_gpioa_lease.captured = false;
    result.primary = nx_stm32u575_gpio_clock_enable(0u);
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    bool gpio_a_available = (NX_U575_READ(&GPIOA->LCKR) & 1536u) == 0u;
    uint32_t gpio_a_pin9_mode = (NX_U575_READ(&GPIOA->MODER) >> 18u) & 3u;
    gpio_a_available = gpio_a_available && (gpio_a_pin9_mode == 0u || gpio_a_pin9_mode == 3u);
    uint32_t gpio_a_pin10_mode = (NX_U575_READ(&GPIOA->MODER) >> 20u) & 3u;
    gpio_a_available = gpio_a_available && (gpio_a_pin10_mode == 0u || gpio_a_pin10_mode == 3u);
    if (!gpio_a_available) {
        result.primary = NX_ERROR_BUSY;
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_gpioa_lease.mode = NX_U575_READ(&GPIOA->MODER) & 3932160u;
    s_nx_gpioa_lease.type = NX_U575_READ(&GPIOA->OTYPER) & 1536u;
    s_nx_gpioa_lease.speed = NX_U575_READ(&GPIOA->OSPEEDR) & 3932160u;
    s_nx_gpioa_lease.pull = NX_U575_READ(&GPIOA->PUPDR) & 3932160u;
    s_nx_gpioa_lease.af1 = NX_U575_READ(&GPIOA->AFR[1]) & 4080u;
    s_nx_gpioa_lease.odr = NX_U575_READ(&GPIOA->ODR) & 1536u;
    s_nx_gpioa_lease.captured = true;
    NX_U575_WRITE(&RCC->APB2ENR, NX_U575_READ(&RCC->APB2ENR) | (RCC_APB2ENR_USART1EN));
    nx_arch_dsb();
    if ((NX_U575_READ(&RCC->APB2ENR) & (RCC_APB2ENR_USART1EN)) != (RCC_APB2ENR_USART1EN)) {
        result.primary = NX_ERROR_IO;
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_CONTROLLER, 0u);
    s_nx_platform_initialized = 1u;
    result.primary = prepare_console();
    if (result.primary != NX_SUCCESS) {
        result.cleanup = nx_platform_stop_impl(diagnostic, true);
        result.remaining_effects = result.cleanup == NX_SUCCESS ? 0u : 1u;
        return result;
    }
    s_nx_platform_initialized = 1u;
    nx_platform_diagnostic_phase(diagnostic, false, NX_PLATFORM_PHASE_NONE, SIZE_MAX);
    return result;
}

/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_gpio_port_t* nx_factory_gpio(nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_uart_port_t* nx_factory_uart(nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return nx_binding_console;
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_port_t* nx_factory_spi(nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_port_t* nx_factory_i2c(nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_flash_port_t* nx_factory_flash(nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_watchdog_port_t* nx_factory_watchdog(nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_exti_port_t* nx_factory_exti(nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_port_t* nx_factory_pwm(nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_port_t* nx_factory_adc(nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_port_t* nx_factory_can(nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_device_port_t* nx_factory_usb_device(nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_port_t* nx_factory_eth(nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_timer_capture_t* nx_factory_timer_capture(nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_advanced_pwm_t* nx_factory_advanced_pwm(nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_group_t* nx_factory_pwm_group(nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_encoder_t* nx_factory_encoder(nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_pwm_adc_t* nx_factory_pwm_adc(nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_can_fd_port_t* nx_factory_can_fd(nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_adc_group_port_t* nx_factory_adc_group(nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_eth_frames_port_t* nx_factory_eth_frames(nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_rtc_port_t* nx_factory_rtc(nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_lptim_port_t* nx_factory_lptim(nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_spi_endpoint_t* nx_factory_spi_device(nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_i2c_endpoint_t* nx_factory_i2c_device(nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_usb_endpoint_port_t* nx_factory_usb_endpoint(nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure typed lookup; lifecycle remains explicit. */
const nx_mdio_port_t* nx_factory_mdio(nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_gpio_capability(
    nx_gpio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_io_capability_t s_nx_capability_uart_console = {
    NX_FACTORY_CAP_IRQ, 0U, 1U, 1U, 0U
};
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_uart_capability(
    nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return &s_nx_capability_uart_console;
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_capability(
    nx_spi_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_capability(
    nx_i2c_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_flash_capability(
    nx_flash_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_watchdog_capability(
    nx_watchdog_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_exti_capability(
    nx_exti_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_capability(
    nx_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_capability(
    nx_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_capability(
    nx_can_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_device_capability(
    nx_usb_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_capability(
    nx_eth_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_timer_capture_capability(
    nx_timer_capture_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_advanced_pwm_capability(
    nx_advanced_pwm_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_group_capability(
    nx_pwm_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_encoder_capability(
    nx_encoder_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_pwm_adc_capability(
    nx_pwm_adc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_can_fd_capability(
    nx_can_fd_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_adc_group_capability(
    nx_adc_group_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_eth_frames_capability(
    nx_eth_frames_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_rtc_capability(
    nx_rtc_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_lptim_capability(
    nx_lptim_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_spi_device_capability(
    nx_spi_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_i2c_device_capability(
    nx_i2c_device_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_usb_endpoint_capability(
    nx_usb_endpoint_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
/** \brief Pure selected-only capability lookup. */
const nx_factory_io_capability_t* nx_factory_mdio_capability(
    nx_mdio_id_t id) {
    switch (id) {
        default:
            return NULL;
    }
}
static const nx_factory_uart_traits_t s_nx_traits_uart_console = {
    8U,
    0U,
    2U,
    115200U,
    NX_IO_ABORT_REQUEST,
    NX_IO_CONTINUITY_IRQ_BUFFERED,
    NX_IO_TIMESTAMP_UNKNOWN,
    NX_IO_DMA_POLICY_NONE,
    0U,
};
/** \brief Pure selected-mode traits lookup. */
const nx_factory_uart_traits_t* nx_factory_uart_traits(
    nx_uart_id_t id) {
    switch (id) {
        case NX_UART_ID_CONSOLE:
            return &s_nx_traits_uart_console;
        default:
            return NULL;
    }
}
