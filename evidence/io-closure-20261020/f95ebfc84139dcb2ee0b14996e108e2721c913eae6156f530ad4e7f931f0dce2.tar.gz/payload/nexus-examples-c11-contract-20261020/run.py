import json,os,resource,sys,time
from pathlib import Path
root=Path('/tmp/nexus-quality-20261019');sys.path.insert(0,str(root))
from tools.dev.process import run
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
env=os.environ.copy();env.update(PATH=str(root/'.venv/bin')+':/tmp/nexus-quality-arm/bin:/usr/local/bin:/usr/bin:/bin',NEXUS_BUILD_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1',PYTHONDONTWRITEBYTECODE='1')
command=['flock','/tmp/nexus-platform-compiler.lock',sys.executable,'-B','scripts/test_build_contracts.py','-v']
start=time.monotonic();r=run(command,cwd=Path('/tmp/nexus-examples-completion-20261020'),env=env,timeout=300,log=out/'complete.raw',stage='examples-C11-application-contract')
report={'argv':command,'exit_code':r.returncode,'duration_s':time.monotonic()-start,'peak_child_rss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'physical_status':'not_executed','qualification':False}
(out/'execution.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));print(r.stderr[-5000:]);raise SystemExit(r.returncode)
