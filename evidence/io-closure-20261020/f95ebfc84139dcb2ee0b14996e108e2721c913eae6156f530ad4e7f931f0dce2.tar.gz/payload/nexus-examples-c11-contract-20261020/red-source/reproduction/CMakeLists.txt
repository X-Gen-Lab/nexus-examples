cmake_minimum_required(VERSION 3.31)
project(nexus_installed_reference LANGUAGES C ASM)

# The installed SDK is a separate, verified input; this project owns main.
find_package(Nexus CONFIG REQUIRED)
nexus_add_firmware(nexus_firmware SOURCES main.c rx_policy.c)
get_target_property(soc_family Nexus::Platform NEXUS_SOC_FAMILY)
if(soc_family STREQUAL "native")
    enable_testing()
    add_test(NAME installed_platform_reference COMMAND nexus_firmware)
    set_tests_properties(installed_platform_reference PROPERTIES TIMEOUT 10)
endif()
