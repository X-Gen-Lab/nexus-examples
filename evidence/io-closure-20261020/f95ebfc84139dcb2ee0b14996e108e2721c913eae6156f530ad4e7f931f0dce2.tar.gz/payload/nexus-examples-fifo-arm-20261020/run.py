import hashlib
import json
import os
from pathlib import Path
import resource
import sys
import time

primary = Path('/tmp/nexus-quality-20261019')
root = Path('/tmp/nexus-examples-completion-20261020')
out = Path(__file__).parent
sys.path.insert(0, str(primary))
from tools.dev.process import run

sdk = root / 'external/nexus'
env = os.environ.copy()
env.update(PATH=str(primary / '.venv/bin') + ':/tmp/nexus-quality-arm/bin:/usr/local/bin:/usr/bin:/bin',
           NEXUS_BUILD_JOBS='1', CMAKE_BUILD_PARALLEL_LEVEL='1',
           PYTHONDONTWRITEBYTECODE='1')
rows = []
start = time.monotonic()
for ref in ('h743', 'u575'):
    build = root / 'build' / ('uart-fifo-' + ref)
    if build.exists():
        raise SystemExit('Refuse reuse of an existing build: ' + str(build))
    commands = [
        ['cmake', '-S', str(root / 'apps/uart_fifo_acquisition'), '-B', str(build),
         '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
         '-DCMAKE_TOOLCHAIN_FILE=' + str(sdk / 'cmake/toolchains/arm-gcc.cmake'),
         '-DNEXUS_SOURCE=' + str(sdk),
         '-DNEXUS_ASSEMBLY_FILE=' + str(sdk / 'cmake/package/verification/io_evolution' / (ref + '-uart-fifo.toml'))],
        ['cmake', '--build', str(build), '--target', 'uart_fifo_acquisition', '--parallel', '1'],
    ]
    for i, command in enumerate(commands):
        began = time.monotonic()
        result = run(command, cwd=root, env=env, timeout=600,
                     log=out / (ref + '-' + str(i) + '.raw'),
                     stage='external-fifo-' + ref + '-' + str(i))
        rows.append({'argv': command, 'exit_code': result.returncode,
                     'duration_s': time.monotonic() - began})
        (out / 'execution.json').write_text(json.dumps({
            'commands': rows, 'duration_s': time.monotonic() - start,
            'peak_child_rss_kib': resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
            'physical_status': 'not_executed', 'qualification': False,
        }, indent=2) + '\n')
        print(json.dumps(rows[-1]), flush=True)
        if result.returncode:
            print(result.stderr[-4000:])
            raise SystemExit(result.returncode)
    artifacts = []
    for path in sorted((build / 'bin').iterdir()):
        if path.is_file():
            data = path.read_bytes()
            artifacts.append({'path': str(path), 'size': len(data),
                              'sha256': hashlib.sha256(data).hexdigest()})
    (out / (ref + '-artifacts.json')).write_text(json.dumps(artifacts, indent=2) + '\n')
    print(json.dumps({'reference': ref, 'artifacts': artifacts}), flush=True)
